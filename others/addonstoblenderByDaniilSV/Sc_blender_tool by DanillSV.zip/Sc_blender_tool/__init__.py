bl_info = {
"name": "Supercell Blender mini tools",
"author": "DaniilSV",
"version": (1, 0),
"blender": (3, 0, 0),
"location": "View3D > Sidebar > Supercell tools",
"description": "",
"warning": "",
"wiki_url": "",
"category": "3D View"
}

import bpy
from bpy.types import (
    Operator,
    Panel,
)
from bpy_extras.io_utils import ImportHelper, BoolProperty
from bpy.props import StringProperty, IntProperty
import os
import importlib

if "scw_parser" in locals():
    importlib.reload(scw_parser)
else:
    from . import scw_parser

if "scw_encoder" in locals():
    importlib.reload(scw_encoder)
else:
    from . import scw_encoder

if "glb_parser" in locals():
    importlib.reload(glb_parser)
else:
    from . import glb_parser

if "glb_encoder" in locals():
    importlib.reload(glb_encoder)
else:
    from . import glb_encoder

scw_parser = scw_parser.ScwParser()
scw_writer = scw_encoder.ScwWriter()
glb_writer = glb_encoder.GlbEncoder()

def register_sc_shader_uber():
    if f'SC_shader_uber' not in bpy.data.node_groups:
        group = bpy.data.node_groups.new(type="ShaderNodeTree", name=f'SC_shader_uber')

        # main node
        group.inputs.new("NodeSocketShader", "AMBIENT")
        group.inputs.new("NodeSocketFloat", "Ambient enable")
        group.inputs.new("NodeSocketColor", "Ambient")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "CLIP_PLANE")
        group.inputs.new("NodeSocketFloat", "Clip plane enable")
        group.inputs.new("NodeSocketColor", "Clip plane")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "STENCIL")
        group.inputs.new("NodeSocketFloat", "Stencil enable")
        group.inputs.new("NodeSocketFloat", "Stencil last enable")
        group.inputs.new("NodeSocketColor", "Stencil")
        group.inputs.new("NodeSocketColor", "Stencil alpha")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "COLORIZE")
        group.inputs.new("NodeSocketFloat", "Colorize enable")
        group.inputs.new("NodeSocketColor", "Colorize")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "DIFFUSE")
        group.inputs.new("NodeSocketFloat", "Diffuse enable")
        group.inputs.new("NodeSocketColor", "Diffuse")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "Speculаr")
        group.inputs.new("NodeSocketFloat", "Specular enable")
        group.inputs.new("NodeSocketFloat", "Combine specular and diffuse")
        group.inputs.new("NodeSocketColor", "Specular")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "EMISSION")
        group.inputs.new("NodeSocketFloat", "Emission enable")
        group.inputs.new("NodeSocketColor", "Emission")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "LIGHTMAP")
        group.inputs.new("NodeSocketFloat", "Diffuse lightmap enable")
        group.inputs.new("NodeSocketColor", "Diffuse lightmap")
        group.inputs.new("NodeSocketFloat", "Specular lightmap enable")
        group.inputs.new("NodeSocketColor", "Specular lightmap")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "OPACITY")
        group.inputs.new("NodeSocketFloat", "Opacity enable")
        group.inputs.new("NodeSocketFloat", "Opacity")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketShader", "COLORTRANSFORM")
        group.inputs.new("NodeSocketFloat", "ADD enable")
        group.inputs.new("NodeSocketColor", "ADD")
        group.inputs.new("NodeSocketFloat", "MUL enable")
        group.inputs.new("NodeSocketColor", "MUL")
        group.inputs.new("NodeSocketShader", "")
        group.inputs.new("NodeSocketFloat", "Blender lighting")
        group.inputs.new("NodeSocketFloat", "Shader define(scw only)")

        group.inputs[1].default_value = (0)  ##ambient enable
        group.inputs[1].min_value = (0)
        group.inputs[1].max_value = (1)
        group.inputs[2].default_value = (0, 0, 0, 1)  # ambient color
        group.inputs[5].default_value = (0)  ##clip plane enable
        group.inputs[5].min_value = (0)
        group.inputs[5].max_value = (1)
        group.inputs[6].default_value = (0, 0, 0, 1)  # clip plane color
        group.inputs[9].default_value = (0)  ##Stenctil enable
        group.inputs[9].min_value = (0)
        group.inputs[9].max_value = (1)
        group.inputs[10].default_value = (0)
        group.inputs[10].min_value = (0)
        group.inputs[10].max_value = (1)
        group.inputs[11].default_value = (0, 0, 0, 1)  # Stencil color
        group.inputs[12].default_value = (0, 0, 0, 1)
        group.inputs[15].default_value = (0)  ##Colorize enable
        group.inputs[15].min_value = (0)
        group.inputs[15].max_value = (1)
        group.inputs[16].default_value = (0, 0, 0, 1)  # Colorize color
        group.inputs[19].default_value = (0)  ##Diffuse enable
        group.inputs[19].min_value = (0)
        group.inputs[19].max_value = (1)
        group.inputs[20].default_value = (1, 1, 1, 1)  # Diffuse color
        group.inputs[23].default_value = (0)  ##Specular enable
        group.inputs[23].min_value = (0)
        group.inputs[23].max_value = (1)
        group.inputs[24].default_value = (0)  ##Combine enable
        group.inputs[24].min_value = (0)
        group.inputs[24].max_value = (1)
        group.inputs[25].default_value = (1, 1, 1, 1)  # Specular color
        group.inputs[28].default_value = (0)  ##Emission enable
        group.inputs[28].min_value = (0)
        group.inputs[28].max_value = (1)
        group.inputs[29].default_value = (1, 1, 1, 1)  # Emission color
        group.inputs[32].default_value = (0)  ##Diffuse lightmap enable
        group.inputs[32].min_value = (0)
        group.inputs[32].max_value = (1)
        group.inputs[33].default_value = (1, 1, 1, 1)  # Diffuse lightmap color
        group.inputs[34].default_value = (0)  ##Specular lightmap enable
        group.inputs[34].min_value = (0)
        group.inputs[34].max_value = (1)
        group.inputs[35].default_value = (1, 1, 1, 1)  # Specular lightmap color
        group.inputs[38].default_value = (0)  ##Opacity enable
        group.inputs[38].min_value = (0)
        group.inputs[38].max_value = (1)
        group.inputs[39].default_value = (0)  ##Opacity
        group.inputs[39].min_value = (0)
        group.inputs[39].max_value = (1)
        group.inputs[42].default_value = (0)  ##ADD enable
        group.inputs[42].min_value = (0)
        group.inputs[42].max_value = (1)
        group.inputs[43].default_value = (1, 1, 1, 1)  # ADD color
        group.inputs[44].default_value = (0)  ##MUL enable
        group.inputs[44].min_value = (0)
        group.inputs[44].max_value = (1)
        group.inputs[45].default_value = (1, 1, 1, 1)  # MUL color
        group.inputs[47].default_value = (0)  ##Blender lighting enable
        group.inputs[47].min_value = (0)
        group.inputs[47].max_value = (1)
        group.inputs[48].default_value = (0)  # shader define

        group.outputs.new("NodeSocketShader", "Output")
        # main node code end

        input_node = group.nodes.new("NodeGroupInput")

        output_node = group.nodes.new("NodeGroupOutput")
        output_node.location = (6500, 0)

        ##Gamma
        ambientGamma_g_node = group.nodes.new(type='ShaderNodeGamma')
        ambientGamma_g_node.location = (200, 0)
        ambientGamma_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Ambient'], ambientGamma_g_node.inputs[0])

        ClipPlane_g_node = group.nodes.new(type='ShaderNodeGamma')
        ClipPlane_g_node.location = (200, -125)
        ClipPlane_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Clip plane'], ClipPlane_g_node.inputs[0])

        stencil_g_node = group.nodes.new(type='ShaderNodeGamma')
        stencil_g_node.location = (200, -250)
        stencil_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Stencil'], stencil_g_node.inputs[0])

        stencila_g_node = group.nodes.new(type='ShaderNodeGamma')
        stencila_g_node.location = (200, -260)
        stencila_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Stencil alpha'], stencila_g_node.inputs[0])

        colorize_g_node = group.nodes.new(type='ShaderNodeGamma')
        colorize_g_node.location = (200, -375)
        colorize_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Colorize'], colorize_g_node.inputs[0])

        diffuse_g_node = group.nodes.new(type='ShaderNodeGamma')
        diffuse_g_node.location = (200, -500)
        diffuse_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Diffuse'], diffuse_g_node.inputs[0])

        specular_g_node = group.nodes.new(type='ShaderNodeGamma')
        specular_g_node.location = (200, -625)
        specular_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Specular'], specular_g_node.inputs[0])

        emission_g_node = group.nodes.new(type='ShaderNodeGamma')
        emission_g_node.location = (200, -750)
        emission_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Emission'], emission_g_node.inputs[0])

        dlightmap_g_node = group.nodes.new(type='ShaderNodeGamma')
        dlightmap_g_node.location = (200, -875)
        dlightmap_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Diffuse lightmap'], dlightmap_g_node.inputs[0])

        slightmap_g_node = group.nodes.new(type='ShaderNodeGamma')
        slightmap_g_node.location = (200, -885)
        slightmap_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['Specular lightmap'], slightmap_g_node.inputs[0])

        add_g_node = group.nodes.new(type='ShaderNodeGamma')
        add_g_node.location = (200, -1000)
        add_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['ADD'], add_g_node.inputs[0])

        mul_g_node = group.nodes.new(type='ShaderNodeGamma')
        mul_g_node.location = (200, -1125)
        mul_g_node.inputs[1].default_value = 0.4545
        group.links.new(input_node.outputs['MUL'], mul_g_node.inputs[0])
        # gamma end

        # diffuse node
        diff_math_1 = group.nodes.new(type='ShaderNodeMath')
        diff_math_1.operation = 'SUBTRACT'
        diff_math_1.location = (400, 0)
        diff_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Diffuse enable'], diff_math_1.inputs[0])

        diff_math_2 = group.nodes.new(type='ShaderNodeMath')
        diff_math_2.operation = 'ABSOLUTE'
        diff_math_2.location = (550, 0)
        group.links.new(diff_math_2.inputs[0], diff_math_1.outputs[0])

        diff_math_3 = group.nodes.new(type='ShaderNodeMath')
        diff_math_3.operation = 'GREATER_THAN'
        diff_math_3.location = (700, 0)
        diff_math_3.inputs[1].default_value = 0.0
        group.links.new(diff_math_3.inputs[0], diff_math_2.outputs[0])

        diff_color_0 = group.nodes.new(type='ShaderNodeRGB')
        diff_color_0.location = (650, -200)
        diff_color_0.outputs[0].default_value = (1, 1, 1, 1)

        diff_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        diff_color_1.location = (950, 100)
        group.links.new(diff_math_3.outputs[0], diff_color_1.inputs[0])
        group.links.new(diffuse_g_node.outputs[0], diff_color_1.inputs[1])
        group.links.new(diff_color_0.outputs[0], diff_color_1.inputs[2])
        # diffuse node end

        # diffuse lightmap
        diff_lightmap_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        diff_lightmap_color_1.blend_type = 'MULTIPLY'
        diff_lightmap_color_1.location = (1150, 100)
        group.links.new(diff_color_1.outputs[0], diff_lightmap_color_1.inputs[1])
        group.links.new(dlightmap_g_node.outputs[0], diff_lightmap_color_1.inputs[2])

        diffl_math_1 = group.nodes.new(type='ShaderNodeMath')
        diffl_math_1.operation = 'SUBTRACT'
        diffl_math_1.location = (850, -100)
        diffl_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Diffuse lightmap enable'], diffl_math_1.inputs[0])

        diffl_math_2 = group.nodes.new(type='ShaderNodeMath')
        diffl_math_2.operation = 'ABSOLUTE'
        diffl_math_2.location = (1000, -100)
        group.links.new(diffl_math_2.inputs[0], diffl_math_1.outputs[0])

        diffl_math_3 = group.nodes.new(type='ShaderNodeMath')
        diffl_math_3.operation = 'GREATER_THAN'
        diffl_math_3.location = (1150, -100)
        diffl_math_3.inputs[1].default_value = 0.0
        group.links.new(diffl_math_3.inputs[0], diffl_math_2.outputs[0])

        diffl_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        diffl_color_1.location = (1350, -50)
        group.links.new(diffl_math_3.outputs[0], diffl_color_1.inputs[0])
        group.links.new(diff_lightmap_color_1.outputs[0], diffl_color_1.inputs[1])
        group.links.new(diff_color_1.outputs[0], diffl_color_1.inputs[2])
        ##diffuse lightmap end

        # colorize
        colorize_color_node = group.nodes.new(type='ShaderNodeMixRGB')
        colorize_color_node.blend_type = 'MULTIPLY'
        colorize_color_node.location = (1600, -50)
        group.links.new(diffl_color_1.outputs[0], colorize_color_node.inputs[1])
        group.links.new(colorize_g_node.outputs[0], colorize_color_node.inputs[2])

        colorize_math_1 = group.nodes.new(type='ShaderNodeMath')
        colorize_math_1.operation = 'SUBTRACT'
        colorize_math_1.location = (1300, -250)
        colorize_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Colorize enable'], colorize_math_1.inputs[0])

        colorize_math_2 = group.nodes.new(type='ShaderNodeMath')
        colorize_math_2.operation = 'ABSOLUTE'
        colorize_math_2.location = (1500, -250)
        group.links.new(colorize_math_2.inputs[0], colorize_math_1.outputs[0])

        colorize_math_3 = group.nodes.new(type='ShaderNodeMath')
        colorize_math_3.operation = 'GREATER_THAN'
        colorize_math_3.location = (1700, -250)
        colorize_math_3.inputs[1].default_value = 0.0
        group.links.new(colorize_math_3.inputs[0], colorize_math_2.outputs[0])

        colorize_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        colorize_color_1.location = (1800, 0)
        group.links.new(colorize_math_3.outputs[0], colorize_color_1.inputs[0])
        group.links.new(colorize_color_node.outputs[0], colorize_color_1.inputs[1])
        group.links.new(diffl_color_1.outputs[0], colorize_color_1.inputs[2])
        # colorize end

        # ambient
        ambient_color_node = group.nodes.new(type='ShaderNodeMixRGB')
        ambient_color_node.blend_type = 'ADD'
        ambient_color_node.location = (1950, 0)
        group.links.new(colorize_color_1.outputs[0], ambient_color_node.inputs[1])
        group.links.new(ambientGamma_g_node.outputs[0], ambient_color_node.inputs[2])

        ambient_math_1 = group.nodes.new(type='ShaderNodeMath')
        ambient_math_1.operation = 'SUBTRACT'
        ambient_math_1.location = (1500, 200)
        ambient_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Ambient enable'], ambient_math_1.inputs[0])

        ambient_math_2 = group.nodes.new(type='ShaderNodeMath')
        ambient_math_2.operation = 'ABSOLUTE'
        ambient_math_2.location = (1700, 200)
        group.links.new(ambient_math_2.inputs[0], ambient_math_1.outputs[0])

        ambient_math_3 = group.nodes.new(type='ShaderNodeMath')
        ambient_math_3.operation = 'GREATER_THAN'
        ambient_math_3.location = (1900, 200)
        ambient_math_3.inputs[1].default_value = 0.0
        group.links.new(ambient_math_3.inputs[0], ambient_math_2.outputs[0])

        ambient_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        ambient_color_1.location = (2100, 0)
        group.links.new(ambient_math_3.outputs[0], ambient_color_1.inputs[0])
        group.links.new(ambient_color_node.outputs[0], ambient_color_1.inputs[1])
        group.links.new(colorize_color_1.outputs[0], ambient_color_1.inputs[2])
        # ambient end

        # Stencil node
        stencil_color_0 = group.nodes.new(type='ShaderNodeMixRGB')
        stencil_color_0.blend_type = 'MIX'
        stencil_color_0.location = (2250, 0)
        group.links.new(stencila_g_node.outputs[0], stencil_color_0.inputs[0])
        group.links.new(ambient_color_1.outputs[0], stencil_color_0.inputs[1])
        group.links.new(stencil_g_node.outputs[0], stencil_color_0.inputs[2])

        stencil_math_1 = group.nodes.new(type='ShaderNodeMath')
        stencil_math_1.operation = 'SUBTRACT'
        stencil_math_1.location = (1900, -200)
        stencil_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Stencil enable'], stencil_math_1.inputs[0])

        stencil_math_2 = group.nodes.new(type='ShaderNodeMath')
        stencil_math_2.operation = 'ABSOLUTE'
        stencil_math_2.location = (2100, -200)
        group.links.new(stencil_math_2.inputs[0], stencil_math_1.outputs[0])

        stencil_math_3 = group.nodes.new(type='ShaderNodeMath')
        stencil_math_3.operation = 'GREATER_THAN'
        stencil_math_3.location = (2300, -200)
        stencil_math_3.inputs[1].default_value = 0.0
        group.links.new(stencil_math_3.inputs[0], stencil_math_2.outputs[0])

        stencil_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        stencil_color_1.location = (2400, 0)
        group.links.new(stencil_math_3.outputs[0], stencil_color_1.inputs[0])
        group.links.new(stencil_color_0.outputs[0], stencil_color_1.inputs[1])
        group.links.new(ambient_color_1.outputs[0], stencil_color_1.inputs[2])
        # Stencil node end

        # emission
        emission_color_node = group.nodes.new(type='ShaderNodeMixRGB')
        emission_color_node.blend_type = 'ADD'
        emission_color_node.location = (2550, 0)
        group.links.new(stencil_color_1.outputs[0], emission_color_node.inputs[1])
        group.links.new(emission_g_node.outputs[0], emission_color_node.inputs[2])

        emission_math_1 = group.nodes.new(type='ShaderNodeMath')
        emission_math_1.operation = 'SUBTRACT'
        emission_math_1.location = (2100, 200)
        emission_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Emission enable'], emission_math_1.inputs[0])

        emission_math_2 = group.nodes.new(type='ShaderNodeMath')
        emission_math_2.operation = 'ABSOLUTE'
        emission_math_2.location = (2300, 200)
        group.links.new(emission_math_2.inputs[0], emission_math_1.outputs[0])

        emission_math_3 = group.nodes.new(type='ShaderNodeMath')
        emission_math_3.operation = 'GREATER_THAN'
        emission_math_3.location = (2500, 200)
        emission_math_3.inputs[1].default_value = 0.0
        group.links.new(emission_math_3.inputs[0], emission_math_2.outputs[0])

        emission_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        emission_color_1.location = (2700, 0)
        group.links.new(emission_math_3.outputs[0], emission_color_1.inputs[0])
        group.links.new(emission_color_node.outputs[0], emission_color_1.inputs[1])
        group.links.new(stencil_color_1.outputs[0], emission_color_1.inputs[2])
        # emission

        # specular
        specular_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        specular_color_1.location = (2900, 200)
        specular_color_1.blend_type = 'MULTIPLY'
        group.links.new(slightmap_g_node.outputs[0], specular_color_1.inputs[1])
        group.links.new(diffuse_g_node.outputs[0], specular_color_1.inputs[2])

        specular_color_2 = group.nodes.new(type='ShaderNodeMixRGB')
        specular_color_2.location = (2900, -200)
        specular_color_2.blend_type = 'MULTIPLY'
        group.links.new(slightmap_g_node.outputs[0], specular_color_2.inputs[1])
        group.links.new(specular_g_node.outputs[0], specular_color_2.inputs[2])

        specular_color_3 = group.nodes.new(type='ShaderNodeMixRGB')
        specular_color_3.location = (3100, 200)
        specular_color_3.blend_type = 'ADD'
        group.links.new(emission_color_1.outputs[0], specular_color_3.inputs[1])
        group.links.new(specular_color_1.outputs[0], specular_color_3.inputs[2])

        specular_color_4 = group.nodes.new(type='ShaderNodeMixRGB')
        specular_color_4.location = (3100, -200)
        specular_color_4.blend_type = 'ADD'
        group.links.new(emission_color_1.outputs[0], specular_color_4.inputs[1])
        group.links.new(specular_color_2.outputs[0], specular_color_4.inputs[2])

        specular_combine_math_1 = group.nodes.new(type='ShaderNodeMath')
        specular_combine_math_1.operation = 'SUBTRACT'
        specular_combine_math_1.location = (2900, 400)
        specular_combine_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Combine specular and diffuse'],
                        specular_combine_math_1.inputs[0])

        specular_combine_math_2 = group.nodes.new(type='ShaderNodeMath')
        specular_combine_math_2.operation = 'ABSOLUTE'
        specular_combine_math_2.location = (3050, 400)
        group.links.new(specular_combine_math_2.inputs[0], specular_combine_math_1.outputs[0])

        specular_combine_math_3 = group.nodes.new(type='ShaderNodeMath')
        specular_combine_math_3.operation = 'GREATER_THAN'
        specular_combine_math_3.location = (3200, 400)
        specular_combine_math_3.inputs[1].default_value = 0.0
        group.links.new(specular_combine_math_3.inputs[0], specular_combine_math_2.outputs[0])

        specular_combine_color = group.nodes.new(type='ShaderNodeMixRGB')
        specular_combine_color.blend_type = 'MIX'
        specular_combine_color.location = (3400, 0)
        group.links.new(specular_combine_math_3.outputs[0], specular_combine_color.inputs[0])
        group.links.new(specular_color_3.outputs[0], specular_combine_color.inputs[1])
        group.links.new(specular_color_4.outputs[0], specular_combine_color.inputs[2])

        specular_math_1 = group.nodes.new(type='ShaderNodeMath')
        specular_math_1.operation = 'SUBTRACT'
        specular_math_1.location = (2900, -400)
        specular_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Specular enable'], specular_math_1.inputs[0])

        specular_math_2 = group.nodes.new(type='ShaderNodeMath')
        specular_math_2.operation = 'ABSOLUTE'
        specular_math_2.location = (3050, -400)
        group.links.new(specular_math_2.inputs[0], specular_math_1.outputs[0])

        specular_math_3 = group.nodes.new(type='ShaderNodeMath')
        specular_math_3.operation = 'GREATER_THAN'
        specular_math_3.location = (3200, -400)
        specular_math_3.inputs[1].default_value = 0.0
        group.links.new(specular_math_3.inputs[0], specular_math_2.outputs[0])

        specular_color_5 = group.nodes.new(type='ShaderNodeMixRGB')
        specular_color_5.location = (3600, 0)
        specular_color_5.blend_type = 'MIX'
        group.links.new(specular_math_3.outputs[0], specular_color_5.inputs[0])
        group.links.new(specular_combine_color.outputs[0], specular_color_5.inputs[1])
        group.links.new(emission_color_1.outputs[0], specular_color_5.inputs[2])

        specular_final_math_1 = group.nodes.new(type='ShaderNodeMath')
        specular_final_math_1.operation = 'SUBTRACT'
        specular_final_math_1.location = (2900, 0)
        specular_final_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Specular lightmap enable'], specular_final_math_1.inputs[0])

        specular_final_math_2 = group.nodes.new(type='ShaderNodeMath')
        specular_final_math_2.operation = 'ABSOLUTE'
        specular_final_math_2.location = (3050, 0)
        group.links.new(specular_final_math_2.inputs[0], specular_final_math_1.outputs[0])

        specular_final_math_3 = group.nodes.new(type='ShaderNodeMath')
        specular_final_math_3.operation = 'GREATER_THAN'
        specular_final_math_3.location = (3200, 0)
        specular_final_math_3.inputs[1].default_value = 0.0
        group.links.new(specular_final_math_3.inputs[0], specular_final_math_2.outputs[0])

        specular_final_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        specular_final_color_1.blend_type = 'MIX'
        specular_final_color_1.location = (3800, 0)
        group.links.new(specular_final_math_3.outputs[0], specular_final_color_1.inputs[0])
        group.links.new(specular_color_5.outputs[0], specular_final_color_1.inputs[1])
        group.links.new(emission_color_1.outputs[0], specular_final_color_1.inputs[2])
        # specular end

        # Stencil last node
        stencil_last_color_0 = group.nodes.new(type='ShaderNodeMixRGB')
        stencil_last_color_0.blend_type = 'MIX'
        stencil_last_color_0.location = (4000, 0)
        group.links.new(stencila_g_node.outputs[0], stencil_last_color_0.inputs[0])
        group.links.new(specular_final_color_1.outputs[0], stencil_last_color_0.inputs[1])
        group.links.new(stencil_g_node.outputs[0], stencil_last_color_0.inputs[2])

        stencil_last_math_1 = group.nodes.new(type='ShaderNodeMath')
        stencil_last_math_1.operation = 'SUBTRACT'
        stencil_last_math_1.location = (3500, -200)
        stencil_last_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Stencil last enable'], stencil_last_math_1.inputs[0])

        stencil_last_math_2 = group.nodes.new(type='ShaderNodeMath')
        stencil_last_math_2.operation = 'ABSOLUTE'
        stencil_last_math_2.location = (3700, -200)
        group.links.new(stencil_last_math_2.inputs[0], stencil_last_math_1.outputs[0])

        stencil_last_math_3 = group.nodes.new(type='ShaderNodeMath')
        stencil_last_math_3.operation = 'GREATER_THAN'
        stencil_last_math_3.location = (3900, -200)
        stencil_last_math_3.inputs[1].default_value = 0.0
        group.links.new(stencil_last_math_3.inputs[0], stencil_last_math_2.outputs[0])

        stencil_last_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        stencil_last_color_1.location = (4200, 0)
        group.links.new(stencil_last_math_3.outputs[0], stencil_last_color_1.inputs[0])
        group.links.new(stencil_last_color_0.outputs[0], stencil_last_color_1.inputs[1])
        group.links.new(specular_final_color_1.outputs[0], stencil_last_color_1.inputs[2])
        # Stencil last node end

        ##Cycles - eeveep

        cevee_rgb = group.nodes.new(type='ShaderNodeRGB')
        cevee_rgb.location = (3000, -400)
        cevee_rgb.outputs[0].default_value = (1, 1, 1, 1)

        cevee_detector = group.nodes.new(type='ShaderNodeShaderToRGB')
        cevee_detector.location = (3200, -400)
        group.links.new(cevee_detector.inputs[0], cevee_rgb.outputs[0])

        cevee_math_1 = group.nodes.new(type='ShaderNodeMath')
        cevee_math_1.operation = 'SUBTRACT'
        cevee_math_1.location = (3400, -400)
        cevee_math_1.inputs[1].default_value = 1.0
        group.links.new(cevee_math_1.inputs[0], cevee_detector.outputs[0])

        cevee_math_2 = group.nodes.new(type='ShaderNodeMath')
        cevee_math_2.operation = 'ABSOLUTE'
        cevee_math_2.location = (3600, -400)
        group.links.new(cevee_math_2.inputs[0], cevee_math_1.outputs[0])

        cevee_math_3 = group.nodes.new(type='ShaderNodeMath')
        cevee_math_3.operation = 'GREATER_THAN'
        cevee_math_3.location = (3800, -400)
        cevee_math_3.inputs[1].default_value = 0.0
        group.links.new(cevee_math_3.inputs[0], cevee_math_2.outputs[0])

        cevee_shader = group.nodes.new(type='ShaderNodeScript')
        cevee_shader.location = (3000, -600)
        cevee_shader.mode = 'EXTERNAL'
        cevee_shader.name = "Sc_shader_osl"
        shader = open('uber.oso', 'wb')
        shader.write(
            b'OpenShadingLanguage 1.00\r\n# Compiled by oslc 1.11.14\r\n# options: -o C:\\Temp\\tmpe7wknbm7.oso -IC:\\Program Files (x86)\\Steam\\steamapps\\common\\Blender\\3.0\\scripts\\addons\\cycles\\shader\r\nshader uber\r\nparam\tcolor\tDiffuseTex\t1 1 1\t\t%read{3,26} %write{2147483647,-1}\r\nparam\tcolor\tSpecularTex\t1 1 1\t\t%read{28,28} %write{2147483647,-1}\r\nparam\tcolor\tDiffuseLightmap\t1 1 1\t\t%read{6,6} %write{2147483647,-1}\r\nparam\tcolor\tSpecularLightmap\t1 1 1\t\t%read{26,28} %write{2147483647,-1}\r\nparam\tcolor\tColorizeTex\t1 1 1\t\t%read{9,9} %write{2147483647,-1}\r\nparam\tcolor\tAmbientTex\t1 1 1\t\t%read{11,11} %write{2147483647,-1}\r\nparam\tcolor\tEmissionTex\t1 1 1\t\t%read{19,19} %write{2147483647,-1}\r\nparam\tcolor\tStencilTex\t1 1 1\t\t%read{16,34} %write{2147483647,-1}\r\nparam\tcolor\tStencilAlpha\t1 1 1\t\t%read{14,34} %write{2147483647,-1}\r\nparam\tint\tDiffuseColor_enable\t0\t\t%read{1,1} %write{2147483647,-1}\r\nparam\tint\tAmbientColor_enable\t0\t\t%read{10,10} %write{2147483647,-1}\r\nparam\tint\tStencil_enable\t0\t\t%read{12,12} %write{2147483647,-1}\r\nparam\tint\tStencilLast_enable\t0\t\t%read{30,30} %write{2147483647,-1}\r\nparam\tint\tColorizeColor_enable\t0\t\t%read{7,7} %write{2147483647,-1}\r\nparam\tint\tEmissionColor_enable\t0\t\t%read{18,18} %write{2147483647,-1}\r\nparam\tint\tSpecularColor_enable\t0\t\t%read{22,22} %write{2147483647,-1}\r\nparam\tint\tCombineSpecularAndDiffuse\t0\t\t%read{24,24} %write{2147483647,-1}\r\nparam\tint\tDiffuseLightmap_enable\t0\t\t%read{4,4} %write{2147483647,-1}\r\nparam\tint\tSpecularLightmap_enable\t0\t\t%read{20,20} %write{2147483647,-1}\r\noparam\tcolor\tfragColor\t0 0 0\t\t%read{2147483647,-1} %write{36,36}\r\nlocal\tcolor\tFinalColor\t%read{6,36} %write{0,35}\r\nconst\tcolor\t$const1\t1 1 1\t\t%read{0,0} %write{2147483647,-1}\r\nconst\tint\t$const2\t1\t\t%read{1,30} %write{2147483647,-1}\r\ntemp\tint\t$tmp1\t%read{2,2} %write{1,1}\r\ntemp\tint\t$tmp2\t%read{5,5} %write{4,4}\r\ntemp\tint\t$tmp3\t%read{8,8} %write{7,7}\r\ntemp\tint\t$tmp4\t%read{13,13} %write{12,12}\r\nconst\tfloat\t$const3\t1\t\t%read{14,32} %write{2147483647,-1}\r\ntemp\tcolor\t$tmp5\t%read{15,15} %write{14,14}\r\ntemp\tcolor\t$tmp6\t%read{17,17} %write{15,15}\r\ntemp\tcolor\t$tmp7\t%read{17,17} %write{16,16}\r\ntemp\tint\t$tmp8\t%read{21,21} %write{20,20}\r\ntemp\tint\t$tmp9\t%read{23,23} %write{22,22}\r\ntemp\tint\t$tmp10\t%read{25,25} %write{24,24}\r\ntemp\tcolor\t$tmp11\t%read{27,27} %write{26,26}\r\ntemp\tcolor\t$tmp12\t%read{29,29} %write{28,28}\r\ntemp\tint\t$tmp13\t%read{31,31} %write{30,30}\r\ntemp\tcolor\t$tmp14\t%read{33,33} %write{32,32}\r\ntemp\tcolor\t$tmp15\t%read{35,35} %write{33,33}\r\ntemp\tcolor\t$tmp16\t%read{35,35} %write{34,34}\r\ncode ___main___\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:29\r\n# \t\r\n\tassign\t\tFinalColor $const1 \t%filename{"C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl"} %line{29} %argrw{"wr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:31\r\n# \t{\r\n\teq\t\t$tmp1 DiffuseColor_enable $const2 \t%line{31} %argrw{"wrr"}\r\n\tif\t\t$tmp1 4 4 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:33\r\n# \t}\r\n\tassign\t\tFinalColor DiffuseTex \t%line{33} %argrw{"wr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:36\r\n# \t{\r\n\teq\t\t$tmp2 DiffuseLightmap_enable $const2 \t%line{36} %argrw{"wrr"}\r\n\tif\t\t$tmp2 7 7 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:38\r\n# \t}\r\n\tmul\t\tFinalColor FinalColor DiffuseLightmap \t%line{38} %argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:41\r\n# \t{\r\n\teq\t\t$tmp3 ColorizeColor_enable $const2 \t%line{41} %argrw{"wrr"}\r\n\tif\t\t$tmp3 10 10 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:43\r\n# \t}\r\n\tmul\t\tFinalColor FinalColor ColorizeTex \t%line{43} %argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:46\r\n# \t{\r\n\tif\t\tAmbientColor_enable 12 12 \t%line{46} %argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:48\r\n# \t}\r\n\tadd\t\tFinalColor FinalColor AmbientTex \t%line{48} %argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:51\r\n# \t{\r\n\teq\t\t$tmp4 Stencil_enable $const2 \t%line{51} %argrw{"wrr"}\r\n\tif\t\t$tmp4 18 18 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:53\r\n# \t}\r\n\tsub\t\t$tmp5 $const3 StencilAlpha \t%line{53} %argrw{"wrr"}\r\n\tmul\t\t$tmp6 FinalColor $tmp5 \t%argrw{"wrr"}\r\n\tmul\t\t$tmp7 StencilTex StencilAlpha \t%argrw{"wrr"}\r\n\tadd\t\tFinalColor $tmp6 $tmp7 \t%argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:56\r\n# \t{\r\n\tif\t\tEmissionColor_enable 20 20 \t%line{56} %argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:58\r\n# \t}\r\n\tadd\t\tFinalColor FinalColor EmissionTex \t%line{58} %argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:61\r\n# \t{\r\n\teq\t\t$tmp8 SpecularLightmap_enable $const2 \t%line{61} %argrw{"wrr"}\r\n\tif\t\t$tmp8 30 30 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:63\r\n# \t\t{\r\n\teq\t\t$tmp9 SpecularColor_enable $const2 \t%line{63} %argrw{"wrr"}\r\n\tif\t\t$tmp9 30 30 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:65\r\n# \t\t\t{\r\n\teq\t\t$tmp10 CombineSpecularAndDiffuse $const2 \t%line{65} %argrw{"wrr"}\r\n\tif\t\t$tmp10 28 30 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:67\r\n# \t\t\t}\r\n\tmul\t\t$tmp11 SpecularLightmap DiffuseTex \t%line{67} %argrw{"wrr"}\r\n\tadd\t\tFinalColor FinalColor $tmp11 \t%argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:72\r\n# \t\t\t}\r\n\tmul\t\t$tmp12 SpecularLightmap SpecularTex \t%line{72} %argrw{"wrr"}\r\n\tadd\t\tFinalColor FinalColor $tmp12 \t%argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:77\r\n# \t{\r\n\teq\t\t$tmp13 StencilLast_enable $const2 \t%line{77} %argrw{"wrr"}\r\n\tif\t\t$tmp13 36 36 \t%argrw{"r"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:79\r\n# \t}\r\n\tsub\t\t$tmp14 $const3 StencilAlpha \t%line{79} %argrw{"wrr"}\r\n\tmul\t\t$tmp15 FinalColor $tmp14 \t%argrw{"wrr"}\r\n\tmul\t\t$tmp16 StencilTex StencilAlpha \t%argrw{"wrr"}\r\n\tadd\t\tFinalColor $tmp15 $tmp16 \t%argrw{"wrr"}\r\n# C:\\\\Desktop\\\\Brawl stars - shader\\\\uber.osl:81\r\n# \t\r\n\tassign\t\tfragColor FinalColor \t%line{81} %argrw{"wr"}\r\n\tend\r\n')
        shader.close()
        cevee_shader.use_auto_update = True
        cevee_shader.filepath = os.path.abspath('uber.oso')

        group.links.new(diffuse_g_node.outputs[0], cevee_shader.inputs[0])
        group.links.new(specular_g_node.outputs[0], cevee_shader.inputs[1])
        group.links.new(dlightmap_g_node.outputs[0], cevee_shader.inputs[2])
        group.links.new(slightmap_g_node.outputs[0], cevee_shader.inputs[3])
        group.links.new(colorize_g_node.outputs[0], cevee_shader.inputs[4])
        group.links.new(ambientGamma_g_node.outputs[0], cevee_shader.inputs[5])
        group.links.new(emission_g_node.outputs[0], cevee_shader.inputs[6])
        group.links.new(stencil_g_node.outputs[0], cevee_shader.inputs[7])
        group.links.new(stencila_g_node.outputs[0], cevee_shader.inputs[8])
        group.links.new(input_node.outputs['Diffuse enable'], cevee_shader.inputs[9])
        group.links.new(input_node.outputs['Ambient enable'], cevee_shader.inputs[10])
        group.links.new(input_node.outputs['Stencil enable'], cevee_shader.inputs[11])
        group.links.new(input_node.outputs['Stencil last enable'], cevee_shader.inputs[12])
        group.links.new(input_node.outputs['Colorize enable'], cevee_shader.inputs[13])
        group.links.new(input_node.outputs['Emission enable'], cevee_shader.inputs[14])
        group.links.new(input_node.outputs['Specular enable'], cevee_shader.inputs[15])
        group.links.new(input_node.outputs['Combine specular and diffuse'], cevee_shader.inputs[16])
        group.links.new(input_node.outputs['Diffuse lightmap enable'], cevee_shader.inputs[17])
        group.links.new(input_node.outputs['Specular lightmap enable'], cevee_shader.inputs[18])

        cevee_color_node = group.nodes.new(type='ShaderNodeMixRGB')
        cevee_color_node.location = (4000, -400)
        group.links.new(cevee_math_3.outputs[0], cevee_color_node.inputs[0])
        group.links.new(stencil_last_color_1.outputs[0], cevee_color_node.inputs[1])
        group.links.new(cevee_shader.outputs[0], cevee_color_node.inputs[2])
        ##Cycles - eevee end

        # colortransform add
        colortransfrom_add_color_node = group.nodes.new(type='ShaderNodeMixRGB')
        colortransfrom_add_color_node.blend_type = 'ADD'
        colortransfrom_add_color_node.location = (4400, 0)
        group.links.new(cevee_color_node.outputs[0], colortransfrom_add_color_node.inputs[1])
        group.links.new(add_g_node.outputs[0], colortransfrom_add_color_node.inputs[2])

        colortransfrom_add_math_1 = group.nodes.new(type='ShaderNodeMath')
        colortransfrom_add_math_1.operation = 'SUBTRACT'
        colortransfrom_add_math_1.location = (3900, 200)
        colortransfrom_add_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['ADD enable'], colortransfrom_add_math_1.inputs[0])

        colortransfrom_add_math_2 = group.nodes.new(type='ShaderNodeMath')
        colortransfrom_add_math_2.operation = 'ABSOLUTE'
        colortransfrom_add_math_2.location = (4100, 200)
        group.links.new(colortransfrom_add_math_2.inputs[0], colortransfrom_add_math_1.outputs[0])

        colortransfrom_add_math_3 = group.nodes.new(type='ShaderNodeMath')
        colortransfrom_add_math_3.operation = 'GREATER_THAN'
        colortransfrom_add_math_3.location = (4300, 200)
        colortransfrom_add_math_3.inputs[1].default_value = 0.0
        group.links.new(colortransfrom_add_math_3.inputs[0], colortransfrom_add_math_2.outputs[0])

        colortransfrom_add_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        colortransfrom_add_color_1.location = (4600, 0)
        group.links.new(colortransfrom_add_math_3.outputs[0], colortransfrom_add_color_1.inputs[0])
        group.links.new(colortransfrom_add_color_node.outputs[0], colortransfrom_add_color_1.inputs[1])
        group.links.new(cevee_color_node.outputs[0], colortransfrom_add_color_1.inputs[2])
        # colortransform add end

        # colortransform mul
        colortransfrom_mul_color_node = group.nodes.new(type='ShaderNodeMixRGB')
        colortransfrom_mul_color_node.blend_type = 'MULTIPLY'
        colortransfrom_mul_color_node.location = (4800, 0)
        group.links.new(colortransfrom_add_color_1.outputs[0], colortransfrom_mul_color_node.inputs[1])
        group.links.new(mul_g_node.outputs[0], colortransfrom_mul_color_node.inputs[2])

        colortransfrom_mul_math_1 = group.nodes.new(type='ShaderNodeMath')
        colortransfrom_mul_math_1.operation = 'SUBTRACT'
        colortransfrom_mul_math_1.location = (4200, -200)
        colortransfrom_mul_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['MUL enable'], colortransfrom_mul_math_1.inputs[0])

        colortransfrom_mul_math_2 = group.nodes.new(type='ShaderNodeMath')
        colortransfrom_mul_math_2.operation = 'ABSOLUTE'
        colortransfrom_mul_math_2.location = (4350, -200)
        group.links.new(colortransfrom_mul_math_2.inputs[0], colortransfrom_mul_math_1.outputs[0])

        colortransfrom_mul_math_3 = group.nodes.new(type='ShaderNodeMath')
        colortransfrom_mul_math_3.operation = 'GREATER_THAN'
        colortransfrom_mul_math_3.location = (4550, -200)
        colortransfrom_mul_math_3.inputs[1].default_value = 0.0
        group.links.new(colortransfrom_mul_math_3.inputs[0], colortransfrom_mul_math_2.outputs[0])

        colortransfrom_mul_color_1 = group.nodes.new(type='ShaderNodeMixRGB')
        colortransfrom_mul_color_1.location = (5000, 0)
        group.links.new(colortransfrom_mul_math_3.outputs[0], colortransfrom_mul_color_1.inputs[0])
        group.links.new(colortransfrom_mul_color_node.outputs[0], colortransfrom_mul_color_1.inputs[1])
        group.links.new(colortransfrom_add_color_1.outputs[0], colortransfrom_mul_color_1.inputs[2])
        # colortransform mul end

        # clip plane + opacity
        pos = group.nodes.new(type='ShaderNodeNewGeometry')
        pos.location = (3000, -1000)

        pos_x = group.nodes.new(type='ShaderNodeSeparateXYZ')
        pos_x.location = (3200, -800)
        group.links.new(pos.outputs[0], pos_x.inputs[0])

        pos_y = group.nodes.new(type='ShaderNodeSeparateXYZ')
        pos_y.location = (3200, -1000)
        group.links.new(pos.outputs[0], pos_y.inputs[0])

        pos_z = group.nodes.new(type='ShaderNodeSeparateXYZ')
        pos_z.location = (3200, -1200)
        group.links.new(pos.outputs[0], pos_z.inputs[0])

        pos_x_x = group.nodes.new(type='ShaderNodeSeparateXYZ')
        pos_x_x.location = (3400, -800)
        group.links.new(pos_x.outputs[2], pos_x_x.inputs[0])

        pos_y_x = group.nodes.new(type='ShaderNodeSeparateXYZ')
        pos_y_x.location = (3400, -1000)
        group.links.new(pos_y.outputs[1], pos_y_x.inputs[0])

        pos_z_x = group.nodes.new(type='ShaderNodeSeparateXYZ')
        pos_z_x.location = (3400, -1200)
        group.links.new(pos_z.outputs[0], pos_z_x.inputs[0])

        clip_plane_math_1 = group.nodes.new(type='ShaderNodeMath')
        clip_plane_math_1.location = (3600, -800)
        clip_plane_math_1.operation = 'LESS_THAN'
        clip_plane_math_1.inputs[1].default_value = 0.0
        group.links.new(pos_x_x.outputs[0], clip_plane_math_1.inputs[0])

        clip_plane_math_2 = group.nodes.new(type='ShaderNodeMath')
        clip_plane_math_2.location = (3600, -1000)
        clip_plane_math_2.operation = 'LESS_THAN'
        clip_plane_math_2.inputs[1].default_value = 0.0
        group.links.new(pos_y_x.outputs[0], clip_plane_math_2.inputs[0])

        clip_plane_math_3 = group.nodes.new(type='ShaderNodeMath')
        clip_plane_math_3.location = (3600, -1200)
        clip_plane_math_3.operation = 'LESS_THAN'
        clip_plane_math_3.inputs[1].default_value = 0.0
        group.links.new(pos_z_x.outputs[0], clip_plane_math_3.inputs[0])

        clip_plane_math_1_1 = group.nodes.new(type='ShaderNodeMath')
        clip_plane_math_1_1.location = (3800, -800)
        clip_plane_math_1_1.operation = 'MINIMUM'
        clip_plane_math_1_1.inputs[1].default_value = 0.0
        group.links.new(clip_plane_math_1.outputs[0], clip_plane_math_1_1.inputs[0])

        clip_plane_math_2_2 = group.nodes.new(type='ShaderNodeMath')
        clip_plane_math_2_2.location = (3800, -1000)
        clip_plane_math_2_2.operation = 'MINIMUM'
        clip_plane_math_2_2.inputs[1].default_value = 0.0
        group.links.new(clip_plane_math_2.outputs[0], clip_plane_math_2_2.inputs[0])

        clip_plane_math_3_3 = group.nodes.new(type='ShaderNodeMath')
        clip_plane_math_3_3.location = (3800, -1200)
        clip_plane_math_3_3.operation = 'MINIMUM'
        clip_plane_math_3_3.inputs[1].default_value = 0.0
        group.links.new(clip_plane_math_3.outputs[0], clip_plane_math_3_3.inputs[0])

        clip_plane_split_color = group.nodes.new(type='ShaderNodeSeparateRGB')
        clip_plane_split_color.location = (3600, -1400)
        group.links.new(ClipPlane_g_node.outputs[0], clip_plane_split_color.inputs[0])
        group.links.new(clip_plane_split_color.outputs[0], clip_plane_math_1_1.inputs[1])
        group.links.new(clip_plane_split_color.outputs[1], clip_plane_math_2_2.inputs[1])
        group.links.new(clip_plane_split_color.outputs[2], clip_plane_math_3_3.inputs[1])

        clip_plane_color_mix_1 = group.nodes.new(type='ShaderNodeMixRGB')
        clip_plane_color_mix_1.blend_type = 'MIX'
        clip_plane_color_mix_1.location = (4000, -900)
        group.links.new(clip_plane_math_1_1.outputs[0], clip_plane_color_mix_1.inputs[1])
        group.links.new(clip_plane_math_2_2.outputs[0], clip_plane_color_mix_1.inputs[2])

        clip_plane_color_mix_2 = group.nodes.new(type='ShaderNodeMixRGB')
        clip_plane_color_mix_2.blend_type = 'MIX'
        clip_plane_color_mix_2.location = (4200, -1200)
        group.links.new(clip_plane_color_mix_1.outputs[0], clip_plane_color_mix_2.inputs[1])
        group.links.new(clip_plane_math_3_3.outputs[0], clip_plane_color_mix_2.inputs[2])

        clip_plane_color_mix_3 = group.nodes.new(type='ShaderNodeMath')
        clip_plane_color_mix_3.location = (4400, -1200)
        clip_plane_color_mix_3.operation = 'MINIMUM'
        clip_plane_color_mix_3.inputs[1].default_value = 0.5
        group.links.new(clip_plane_color_mix_2.outputs[0], clip_plane_color_mix_3.inputs[0])

        clip_plane_mix_4 = group.nodes.new(type='ShaderNodeGamma')
        clip_plane_mix_4.location = (4600, -1000)
        clip_plane_mix_4.inputs[1].default_value = 0.001
        group.links.new(clip_plane_color_mix_3.outputs[0], clip_plane_mix_4.inputs[0])

        opacity_math_1 = group.nodes.new(type='ShaderNodeMath')
        opacity_math_1.operation = 'SUBTRACT'
        opacity_math_1.location = (4500, -1200)
        opacity_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Clip plane enable'], opacity_math_1.inputs[0])

        opacity_math_2 = group.nodes.new(type='ShaderNodeMath')
        opacity_math_2.operation = 'ABSOLUTE'
        opacity_math_2.location = (4600, -1200)
        group.links.new(opacity_math_2.inputs[0], opacity_math_1.outputs[0])

        opacity_math_3 = group.nodes.new(type='ShaderNodeMath')
        opacity_math_3.operation = 'GREATER_THAN'
        opacity_math_3.location = (4700, -1200)
        opacity_math_3.inputs[1].default_value = 0.0
        group.links.new(opacity_math_3.inputs[0], opacity_math_2.outputs[0])

        opacity_color_node = group.nodes.new(type='ShaderNodeMixRGB')
        opacity_color_node.location = (4800, -1000)
        opacity_color_node.inputs[2].default_value = (0, 0, 0, 1)
        group.links.new(opacity_math_3.outputs[0], opacity_color_node.inputs[0])
        group.links.new(clip_plane_mix_4.outputs[0], opacity_color_node.inputs[1])

        opacity_tex_node = group.nodes.new(type='ShaderNodeInvert')
        opacity_tex_node.location = (4800, -900)
        opacity_tex_node.inputs[0].default_value = 1.0
        group.links.new(input_node.outputs['Opacity'], opacity_tex_node.inputs[1])

        opacity_math_4 = group.nodes.new(type='ShaderNodeMath')
        opacity_math_4.operation = 'SUBTRACT'
        opacity_math_4.location = (4500, -800)
        opacity_math_4.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Opacity enable'], opacity_math_4.inputs[0])

        opacity_math_5 = group.nodes.new(type='ShaderNodeMath')
        opacity_math_5.operation = 'ABSOLUTE'
        opacity_math_5.location = (4600, -800)
        group.links.new(opacity_math_5.inputs[0], opacity_math_4.outputs[0])

        opacity_math_6 = group.nodes.new(type='ShaderNodeMath')
        opacity_math_6.operation = 'GREATER_THAN'
        opacity_math_6.location = (4700, -800)
        opacity_math_6.inputs[1].default_value = 0.0
        group.links.new(opacity_math_6.inputs[0], opacity_math_5.outputs[0])

        opacity_color_node_2 = group.nodes.new(type='ShaderNodeMixRGB')
        opacity_color_node_2.blend_type = 'MIX'
        opacity_color_node_2.location = (5000, -900)
        opacity_color_node_2.inputs[2].default_value = (0, 0, 0, 1)
        group.links.new(opacity_math_6.outputs[0], opacity_color_node_2.inputs[0])
        group.links.new(opacity_tex_node.outputs[0], opacity_color_node_2.inputs[1])

        opacity_mix_1 = group.nodes.new(type='ShaderNodeMixRGB')
        opacity_mix_1.blend_type = 'ADD'
        opacity_mix_1.location = (5200, -1000)
        opacity_mix_1.inputs[0].default_value = 1.0
        group.links.new(opacity_color_node_2.outputs[0], opacity_mix_1.inputs[1])
        group.links.new(opacity_color_node.outputs[0], opacity_mix_1.inputs[2])
        # clip plane + opacity end

        # end shaders blending
        blender_lighting_math_1 = group.nodes.new(type='ShaderNodeMath')
        blender_lighting_math_1.operation = 'SUBTRACT'
        blender_lighting_math_1.location = (4550, 200)
        blender_lighting_math_1.inputs[1].default_value = 1.0
        group.links.new(input_node.outputs['Blender lighting'], blender_lighting_math_1.inputs[0])

        blender_lighting_math_2 = group.nodes.new(type='ShaderNodeMath')
        blender_lighting_math_2.operation = 'ABSOLUTE'
        blender_lighting_math_2.location = (4700, 200)
        group.links.new(blender_lighting_math_2.inputs[0], blender_lighting_math_1.outputs[0])

        blender_lighting_math_3 = group.nodes.new(type='ShaderNodeMath')
        blender_lighting_math_3.operation = 'GREATER_THAN'
        blender_lighting_math_3.location = (4850, 200)
        blender_lighting_math_3.inputs[1].default_value = 0.0
        group.links.new(blender_lighting_math_3.inputs[0], blender_lighting_math_2.outputs[0])

        bl_math_invert = group.nodes.new(type='ShaderNodeInvert')
        bl_math_invert.location = (5000, 200)
        group.links.new(bl_math_invert.inputs[1], blender_lighting_math_3.outputs[0])

        bll_diffuse = group.nodes.new(type='ShaderNodeBsdfDiffuse')
        bll_diffuse.location = (5000, -200)
        bll_diffuse.inputs[1].default_value = 1.0
        group.links.new(bll_diffuse.inputs[0], colortransfrom_mul_color_1.outputs[0])

        bll_mix_last = group.nodes.new(type='ShaderNodeMixShader')
        bll_mix_last.location = (5200, 0)
        group.links.new(bll_mix_last.inputs[0], bl_math_invert.outputs[0])
        group.links.new(bll_mix_last.inputs[1], colortransfrom_mul_color_1.outputs[0])
        group.links.new(bll_mix_last.inputs[2], bll_diffuse.outputs[0])

        transparent_node = group.nodes.new(type='ShaderNodeBsdfTransparent')
        transparent_node.location = (5200, -200)

        opacity_blend = group.nodes.new(type='ShaderNodeMixShader')
        opacity_blend.location = (5400, 0)
        group.links.new(opacity_blend.inputs[0], opacity_mix_1.outputs[0])
        group.links.new(opacity_blend.inputs[1], bll_mix_last.outputs[0])
        group.links.new(opacity_blend.inputs[2], transparent_node.outputs[0])
        group.links.new(opacity_blend.outputs[0], output_node.inputs[0])
        # end of end shaders blending
        # main node end

def register_lightmap_texcoord():
    if 'Lightmap texcoord' not in bpy.data.node_groups:
        uv_group = bpy.data.node_groups.new(type="ShaderNodeTree", name="Lightmap texcoord")
        uv_group.outputs.new("NodeSocketVector", "Output")

        uv_output_node = uv_group.nodes.new("NodeGroupOutput")
        uv_output_node.location = (300, 0)

        texcoord_node = uv_group.nodes.new(type='ShaderNodeTexCoord')

        vector_mod_node = uv_group.nodes.new(type='ShaderNodeVectorTransform')
        vector_mod_node.location = (100, 0)
        vector_mod_node.vector_type = 'NORMAL'
        vector_mod_node.convert_from = 'OBJECT'
        vector_mod_node.convert_to = 'CAMERA'
        uv_group.links.new(texcoord_node.outputs[1], vector_mod_node.inputs[0])

        mapping_node = uv_group.nodes.new(type='ShaderNodeMapping')
        mapping_node.location = (200, 0)
        mapping_node.inputs[1].default_value[0] = 0.5
        mapping_node.inputs[1].default_value[1] = 0.5
        mapping_node.inputs[1].default_value[2] = 0.0
        mapping_node.inputs[3].default_value[0] = 0.5
        mapping_node.inputs[3].default_value[1] = 0.5
        uv_group.links.new(vector_mod_node.outputs[0], mapping_node.inputs[0])
        uv_group.links.new(mapping_node.outputs[0], uv_output_node.inputs[0])

def update_target_rig(self,context):
    scn = context.scene
    if scn.source_rig != "" and scn.target_rig != "":
        set_global_scale(context)

class OT_TOOL_add_material(Operator, ImportHelper):
    bl_idname = "sctool.add_material"
    bl_label = "Import materials from .scw/.glb"
    
    filter_glob: StringProperty(
        default='*.scw;*.glb;',
        options={'HIDDEN'}
    )

    textureNameReplace: BoolProperty(
        name= 'Change texture names to "png"',
        description= 'Changes extensions of all textures to .png and also removes "sc3d/" at beginning, for quick texture assignment',
        default=True,
    )

    importHeader: BoolProperty(
        name= 'Import scene settings (only for scw)',
        description= 'Import scene settings from scw(Animation start/end, framerate)',
        default=False,
    )


    def parse_material(self, context):
        if str(self.filepath).endswith('.scw'):
            file = open(self.filepath, 'rb').read()
            scw_parser.parse(file)
            self.material = scw_parser.scw_material()
            self.header = scw_parser.scw_header()
            if self.importHeader:
                bpy.context.scene.frame_start = self.header['timelineStart']
                bpy.context.scene.frame_end = self.header['timelineEnd']
                bpy.context.scene.render.fps = self.header['sceneFrameRate']
            print(self.material)
            mFilePath = self.header['materialsFile']
            if mFilePath != "":
                try:
                    if os.path.dirname(self.filepath).endswith('sc3d'):
                        mFilePath = f'{os.path.dirname(self.filepath)}\{str(mFilePath).split("/")[1]}'
                    else:
                        mFilePath = f'{os.path.dirname(self.filepath)}\{mFilePath}'

                    mFile = open(mFilePath, 'rb').read()
                    scw_parser.parse(mFile)
                    self.material = []

                    materialCheck = []
                    for m in bpy.data.materials:
                        materialCheck.append(m.name)
                    for n in scw_parser.scw_material():
                        material = n["name"]
                        for t in materialCheck:
                            if material in t:
                                self.material.append(n)

                except FileNotFoundError:
                    self.report({'ERROR'}, f'Material file "{mFilePath}" not found!')
        if str(self.filepath).endswith('.glb'):
            parser = glb_parser.GlbParser(self.filepath)
            glb_type = parser.parse()
            if glb_type != 'flat':
                json = parser.glb_material()
                self.material = json
            else:
                self.report({"ERROR"}, 'Flat is not supported')
                raise Exception("FLA2 chunk")

        orig_render = bpy.context.scene.render.engine
        bpy.context.scene.render.engine = 'CYCLES'
        bpy.context.scene.cycles.shading_system = True
        bpy.context.scene.view_settings.view_transform = 'Raw'

        for i in self.material:
            try:
                a_shader = str(i['shaderFile']).split('/')[1].split('.')[0]
            except:
                a_shader = i['shaderFile']
            if 'uber' in a_shader:
                register_sc_shader_uber()
                register_lightmap_texcoord()
                bpy.context.scene.render.engine = orig_render
                try:
                    self.bl_material = bpy.data.materials[i['name']]
                except:
                    self.report({'WARNING'}, f'Material "{i["name"]}" not found. Created new.')
                    self.bl_material = bpy.data.materials.new(i['name'])

                mat = bpy.data.materials.get(i['name'])
                mat.use_nodes = True
    
                tree = mat.node_tree
                nodes = mat.node_tree.nodes
                for node in nodes:
                    nodes.remove(node)

                links = tree.links
                group_node = tree.nodes.new("ShaderNodeGroup")
                group_node.node_tree = bpy.data.node_groups[f'SC_shader_uber']
                group_node.name = f'SC_shader_uber'
                group_node.location = (-40, 300)
                group_node.use_custom_color = True
                group_node.color = (0, 0, 0)
                group_node.width = 250

                uv_group_node = tree.nodes.new("ShaderNodeGroup")
                uv_group_node.node_tree = bpy.data.node_groups['Lightmap texcoord']
                uv_group_node.name = "UV"
                uv_group_node.location = (-1200, -400)

                materialVar = i["variables"]
                materialEnbl = i["enables"]
                #print(i)

                if i["blendMode"] == 4:
                    mat.blend_method = 'OPAQUE'
                if i["blendMode"] == 2:
                    mat.blend_method = 'CLIP'
                if i["blendMode"] == 1:
                    mat.blend_method = 'HASHED'
                if i["blendMode"] == 0:
                    mat.blend_method = 'BLEND'
                
                
                group_node.inputs[1].default_value = float(materialEnbl["AMBIENT"])
                group_node.inputs[16].default_value = materialVar["ambient"]
                
                if int(materialEnbl["CLIP_PLANE_Z"] ) or int(materialEnbl["CLIP_PLANE_Y"]) or int(materialEnbl["CLIP_PLANE_X"]) > 0:
                    group_node.inputs[5].default_value = 1
                group_node.inputs[6].default_value = (float(materialEnbl["CLIP_PLANE_Z"]), float(materialEnbl["CLIP_PLANE_Y"]), float(materialEnbl["CLIP_PLANE_X"]), 1)
                
                group_node.inputs[15].default_value = float(materialEnbl["COLORIZE"])
                if type(materialVar["colorize"]) is str:
                    if materialVar["colorize"] != ".":
                        if self.textureNameReplace:
                            texName = str(materialVar["colorize"]).split("/")[-1].split(".")[0] + ".png"
                        else:
                            texName = materialVar["colorize"]
                
                        colorize_texture = tree.nodes.new(type='ShaderNodeTexImage')
                        colorize_texture.location = (-400, -100)
                        colorize_texture.name = "colorize_texture"
                        if texName not in bpy.data.images:
                            bl_texture = bpy.data.images.new(texName, 1, 1, alpha=True)
                        else:
                            bl_texture = bpy.data.images.get(texName)
                
                        colorize_texture.image = bl_texture
                
                        links.new(colorize_texture.outputs[0], group_node.inputs[16])
                    else:
                        colorize_texture = tree.nodes.new(type='ShaderNodeTexImage')
                        colorize_texture.location = (-400, -100)
                        links.new(colorize_texture.outputs[0], group_node.inputs[16])
                else:
                    group_node.inputs[16].default_value = materialVar["colorize"]
                
                group_node.inputs[19].default_value = float(materialEnbl["DIFFUSE"])
                if type(materialVar["diffuse"]) is str:
                    if materialVar["diffuse"] != ".":
                        if self.textureNameReplace:
                            texName = str(materialVar["diffuse"]).split("/")[-1].split(".")[0] + ".png"
                        else:
                            texName = materialVar["diffuse"]
                
                        diffuse_texture = tree.nodes.new(type='ShaderNodeTexImage')
                        diffuse_texture.location = (-900, -100)
                        diffuse_texture.name = "diffuse_texture"
                        if texName not in bpy.data.images:
                            bl_texture = bpy.data.images.new(texName, 1, 1, alpha=True)
                        elif f"{texName.split('.')[0]}_highres.png" in bpy.data.images:
                            bl_texture = bpy.data.images.get(f"{texName.split('.')[0]}_highres.png")
                        else:
                            bl_texture = bpy.data.images.get(texName)
                
                        diffuse_texture.image = bl_texture
                
                        links.new(diffuse_texture.outputs[0], group_node.inputs[20])
                    else:
                        diffuse_texture = tree.nodes.new(type='ShaderNodeTexImage')
                        diffuse_texture.location = (-900, -100)
                        links.new(diffuse_texture.outputs[0], group_node.inputs[20])
                else:
                    group_node.inputs[20].default_value = (materialVar["diffuse"])

                group_node.inputs[23].default_value = float(materialEnbl["SPECULAR"])
                group_node.inputs[24].default_value = float(materialEnbl["SPECULAR_COMBINE"])
                if type(materialVar["specular"]) is str:
                    if materialVar["specular"] != ".":
                        if self.textureNameReplace:
                            texName = str(materialVar["specular"]).split("/")[-1].split(".")[0] + ".png"
                        else:
                            texName = materialVar["specular"]

                        specular_texture = tree.nodes.new(type='ShaderNodeTexImage')
                        specular_texture.location = (-650, -200)
                        specular_texture.name = 'specular_texture'
                        if texName not in bpy.data.images:
                            bl_texture = bpy.data.images.new(texName, 1, 1, alpha=True)
                        elif f"{texName.split('.')[0]}_highres.png" in bpy.data.images:
                            bl_texture = bpy.data.images.get(f"{texName.split('.')[0]}_highres.png")
                        else:
                            bl_texture = bpy.data.images.get(texName)

                        specular_texture.image = bl_texture

                        links.new(specular_texture.outputs[0], group_node.inputs[25])
                    else:
                        specular_texture = tree.nodes.new(type='ShaderNodeTexImage')
                        specular_texture.location = (-650, -200)
                        links.new(specular_texture.outputs[0], group_node.inputs[25])
                else:
                    group_node.inputs[25].default_value = materialVar["specular"]

                group_node.inputs[32].default_value = float(materialEnbl["LIGHTMAP_DIFFUSE"])
                if materialVar["lightmapTex2D"] != "":
                    if materialVar["lightmapTex2D"] != "":
                        try:
                            if self.textureNameReplace:
                                texName = str(materialVar["lightmapTex2D"]).split("/")[-1].split(".")[0] + ".png"
                            else:
                                texName = materialVar["lightmapTex2D"]
                        except:
                            if self.textureNameReplace:
                                texName = str(materialVar["lightmapTex2D"]).split("\\")[-1].split(".")[0] + ".png"
                            else:
                                texName = materialVar["lightmapTex2D"]
                
                        diffuse_lightmap_texture = tree.nodes.new(type='ShaderNodeTexImage')
                        diffuse_lightmap_texture.location = (-650, -400)
                        diffuse_lightmap_texture.name = 'diffuse_lightmap_texture'
                        if texName not in bpy.data.images:
                            bl_texture = bpy.data.images.new(texName, 1, 1, alpha=True)
                        else:
                            bl_texture = bpy.data.images.get(texName)

                        diffuse_lightmap_texture.image = bl_texture
                        links.new(diffuse_lightmap_texture.outputs[0], group_node.inputs[33])
                        links.new(uv_group_node.outputs[0], diffuse_lightmap_texture.inputs[0])

                group_node.inputs[34].default_value = float(materialEnbl["LIGHTMAP_SPECULAR"])
                if materialVar["lightmapSpecularTex2D"] != "":
                    try:
                        if self.textureNameReplace:
                            texName = str(materialVar["lightmapSpecularTex2D"]).split("/")[-1].split(".")[0] + ".png"
                        else:
                            texName = materialVar["lightmapSpecularTex2D"]
                    except:
                        if self.textureNameReplace:
                            texName = str(materialVar["lightmapSpecularTex2D"]).split("\\")[-1].split(".")[0] + ".png"
                        else:
                            texName = materialVar["lightmapSpecularTex2D"]

                    specular_lightmap_texture = tree.nodes.new(type='ShaderNodeTexImage')
                    specular_lightmap_texture.location = (-800, -650)
                    specular_lightmap_texture.name = 'specular_lightmap_texture'
                    if texName not in bpy.data.images:
                        bl_texture = bpy.data.images.new(texName, 1, 1, alpha=True)
                    else:
                        bl_texture = bpy.data.images.get(texName)

                    specular_lightmap_texture.image = bl_texture
                    links.new(specular_lightmap_texture.outputs[0], group_node.inputs[35])
                    links.new(uv_group_node.outputs[0], specular_lightmap_texture.inputs[0])

                group_node.inputs[38].default_value = float(materialEnbl["OPACITY"])
                if materialVar['opacityTex2D'] != '':
                    if self.textureNameReplace:
                        texName = str(materialVar["opacityTex2D"]).split("/")[-1].split(".")[0] + ".png"
                    else:
                        texName = materialVar["opacityTex2D"]

                    opacity_texture = tree.nodes.new(type='ShaderNodeTexImage')
                    opacity_texture.location = (-500, -650)
                    opacity_texture.name = 'opacity_texture'
                    if texName not in bpy.data.images:
                        bl_texture = bpy.data.images.new(texName, 1, 1, alpha=True)
                    else:
                        bl_texture = bpy.data.images.get(texName)
                    opacity_texture.image = bl_texture
                    links.new(opacity_texture.outputs[0], group_node.inputs[39])
                else:
                    group_node.inputs[39].default_value = float(materialVar["opacity"])

                if "shaderDefineFlags" in i:
                    group_node.inputs[48].default_value = i["shaderDefineFlags"]
                else:
                    group_node.inputs[48].default_value = 3014

                shader_node_output_material_node = tree.nodes.new(type='ShaderNodeOutputMaterial')
                shader_node_output_material_node.location = (350, 400)
                links.new(group_node.outputs[0], shader_node_output_material_node.inputs[0])


            else:
                self.report({'ERROR'}, f'Shader "{i["shaderFile"].split("/")[1]}" in "{i["name"]}" material not support!')

    def execute(self, context):
        self.parse_material(context)
        return {'FINISHED'}

class OT_TOOL_export_material(Operator, ImportHelper):
    bl_idname = "sctool.export_material"
    bl_label = "Export materials to .scw/.glb"

    filter_glob: StringProperty(
        default='*.scw;*.glb;',
        options={'HIDDEN'}
    )

    customHeader: BoolProperty(
        name='Set custom scene settings(only for scw)',
        description='',
        default=False,
    )   

    animationStart: IntProperty(
        name="Timeline start:",
        description='',
        default = 0
    )

    animationEnd: IntProperty(
        name="Timeline end:",
        description='',
        default = 0
    )

    SceneFramerate: IntProperty(
        name="Framerate:",
        description='',
        default = 30
    )

    materialFile: StringProperty(
        name="Material file:",
        subtype = "FILE_NAME",
        description='',
        default = ''
    )

    def exctract_header_dict(self):
        if self.customHeader:
            header = {}
            header["scwVersion"] = 2
            header["sceneFrameRate"] = self.SceneFramerate

            header["timelineStart"] = self.animationStart
            header["timelineEnd"] = self.animationEnd
            header["materialsFile"] = self.materialFile

            header["unknownBoolean"] = False
            return header
        else:
            header = {}
            header["scwVersion"] = 2
            header["sceneFrameRate"] = int(bpy.context.scene.render.fps)

            header["timelineStart"] = int(bpy.context.scene.frame_start)
            header["timelineEnd"] = int(bpy.context.scene.frame_end)
            header["materialsFile"] = ""

            header["unknownBoolean"] = False
            return header

    def writeMaterial(self):
        if str(self.filepath).endswith(".scw"):
            filedata = open(self.filepath, 'rb').read()

            if self.materialFile != "":
                final_dict = {
                    "header": self.exctract_header_dict(),
                    "materials": [],
                }
            else:
                final_dict = {
                    "header": self.exctract_header_dict(),
                    "materials": self.extract_material_dict(),
                }

            scw_writer.encode(final_dict)
            open(self.filepath, 'wb').write(scw_writer.result + filedata[scw_parser.parse(filedata):])
        elif str(self.filepath).endswith(".glb"):
            filedata = open(self.filepath, 'rb').read()

            parser = glb_parser.GlbParser(self.filepath)
            glb_type = parser.parse()
            if glb_type != 'flat':
                open(self.filepath, 'wb').write(glb_writer.encode(parser.raw_json(), self.extract_material_dict(), filedata[parser.chunk_length():]))
            else:
                self.report({"ERROR"}, 'Flat is not supported')
                raise Exception("FLA2 chunk")

    def extract_material_dict(self):
        materials_data = []
        for i in bpy.data.materials:
            if i.use_nodes:
                for n in i.node_tree.nodes:
                    if "SC_shader_" in n.name:
                        material_a = {}
                        material_a['name'] = i.name
                        shader_node = n
    
                        material_a["shaderFile"] = n.name.replace("SC_shader_", "")
    
                        if i.blend_method == "OPAQUE":
                            material_a["blendMode"] = "4"
                        elif i.blend_method == "BLEND":
                            material_a["blendMode"] = "0"
                        elif i.blend_method == "CLIP":
                            material_a["blendMode"] = "2"
                        elif i.blend_method == "HASHED":
                            material_a["blendMode"] = "1"
    
                        material_a["variables"] = {}
                        variables = material_a["variables"]
    
                        variables["ambient"] = [shader_node.inputs[2].default_value[0], shader_node.inputs[2].default_value[1], shader_node.inputs[2].default_value[2], shader_node.inputs[2].default_value[3]]
    
                        try:
                            shaderInput = shader_node.inputs[20]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            if textureNode == None:
                                variables["diffuse"] = "."
                            else:
                                variables["diffuse"] = textureNode.name
                        except:
                            variables["diffuse"] = [shader_node.inputs[20].default_value[0], shader_node.inputs[20].default_value[1], shader_node.inputs[20].default_value[2], shader_node.inputs[20].default_value[3]]
    
                        try:
                            shaderInput = shader_node.inputs[25]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            if textureNode == None:
                                variables["specular"] = "."
                            else:
                                variables["specular"] = textureNode.name
                        except:
                            variables["specular"] = [shader_node.inputs[25].default_value[0], shader_node.inputs[25].default_value[1], shader_node.inputs[25].default_value[2], shader_node.inputs[25].default_value[3]]
    
                        try:
                            shaderInput = shader_node.inputs[25]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            if textureNode == None:
                                variables["specular"] = "."
                            else:
                                variables["specular"] = textureNode.name
                        except:
                            variables["specular"] = [shader_node.inputs[25].default_value[0], shader_node.inputs[25].default_value[1], shader_node.inputs[25].default_value[2], shader_node.inputs[25].default_value[3]]
    
                        try:
                            shaderInput = shader_node.inputs[16]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            variables["colorize"] = textureNode.name
                        except:
                            variables["colorize"] = [shader_node.inputs[16].default_value[0], shader_node.inputs[16].default_value[1], shader_node.inputs[16].default_value[2], shader_node.inputs[16].default_value[3]]
    
                        try:
                            shaderInput = shader_node.inputs[29]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            variables["emission"] = textureNode.name
                        except:
                            variables["emission"] = [shader_node.inputs[29].default_value[0], shader_node.inputs[29].default_value[1], shader_node.inputs[29].default_value[2], shader_node.inputs[29].default_value[3]]
    
                        try:
                            shaderInput = shader_node.inputs[39]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            variables["opacityTex2D"] = textureNode.name
                            variables["opacity"] = '1.0'
                        except:
                            variables["opacity"] = shader_node.inputs[39].default_value
                            variables["opacityTex2D"] = ''
    
                        try:
                            shaderInput = shader_node.inputs[33]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            variables["lightmapTex2D"] = textureNode.name
                        except:
                            variables["lightmapTex2D"] = ""
    
                        try:
                            shaderInput = shader_node.inputs[35]
                            link = next(link for link in i.node_tree.links if link.to_socket == shaderInput)
                            textureNode = link.from_node.image
                            variables["lightmapSpecularTex2D"] = textureNode.name
                        except:
                            variables["lightmapSpecularTex2D"] = ""
    
                        variables["unk1"] = ''
                        variables["unk2"] = ''
                        variables["unk3"] = ""
                        variables["unknownFloat"] = 0.0
    
                        material_a["shaderDefineFlags"] = int(str(shader_node.inputs[48].default_value).split(".")[0])
    
                        material_a["enables"] = {}
                        enbl = material_a["enables"]
                        enbl["AMBIENT"] = shader_node.inputs[1].default_value
                        enbl["STENCIL"] = shader_node.inputs[9].default_value
                        enbl["CLIP_PLANE_X"] = shader_node.inputs[6].default_value[2]
                        enbl["CLIP_PLANE_Y"] = shader_node.inputs[6].default_value[1]
                        enbl["CLIP_PLANE_Z"] = shader_node.inputs[6].default_value[0]
                        enbl["COLORIZE"] = shader_node.inputs[15].default_value
                        enbl["DIFFUSE"] = shader_node.inputs[19].default_value
                        enbl["SPECULAR"] = shader_node.inputs[23].default_value
                        enbl["SPECULAR_COMBINE"] = '0'
                        enbl["EMISSION"] = shader_node.inputs[28].default_value
                        enbl["LIGHTMAP_DIFFUSE"] = shader_node.inputs[32].default_value
                        enbl["LIGHTMAP_SPECULAR"] = shader_node.inputs[34].default_value
                        enbl["OPACITY"] = shader_node.inputs[38].default_value
    
                        materials_data.append(material_a)

        return materials_data


    def execute(self, context):
        self.writeMaterial()
        return {'FINISHED'}

class TOOL_layout_panel_TransferAnim(Operator):
    bl_idname = "sctool.transfer"
    bl_label = "Transfer"
    bl_description = "Transfer animation from another skeleton"
    
    def execute(self, context):
        self.transfer(context)
        return {'FINISHED'}
    
    def transfer(self, context):
        for bone in bpy.context.selected_pose_bones:
            for dl_const in bone.constraints:
                bone.constraints.remove(dl_const)
            const = bone.constraints.new(type='COPY_TRANSFORMS')
            skeleton = bpy.data.objects[bpy.context.scene.target_rig]
            boneList = []
            const.subtarget = bone.name
            for _bone in skeleton.data.bones:
                boneList.append(_bone.name)
            if bone.name in boneList:
                const.target = skeleton
            else:
                for object in bpy.data.objects:
                    if object.type == "ARMATURE":
                        if object.name != skeleton.name:
                            if object.name != bpy.context.object.name:
                                skeleton_oth = bpy.data.objects[object.name]
                                if bone.name == object.name:
                                    const.target = skeleton_oth
                                    const.subtarget = ''
                                elif bone.name in skeleton_oth.data.bones:
                                    const.target = skeleton_oth

class OT_TOOL_create_shader_selector(Operator):
    bl_idname = "sctool.append_shader"
    bl_label = "append_shader"
    bl_options = {'UNDO'}

    shaders = [('uber', 'uber', 'uber')]

    def get_shader_selects(self, context):
        return OT_TOOL_create_shader_selector.shaders

    shader: bpy.props.EnumProperty(items=shaders, default=None)

    def execute(self, context):
        material = bpy.context.active_object.active_material
        if self.shader == "uber":
            orig_render = bpy.context.scene.render.engine
            bpy.context.scene.render.engine = 'CYCLES'
            bpy.context.scene.cycles.shading_system = True
            bpy.context.scene.view_settings.view_transform = 'Raw'
            register_sc_shader_uber()
            register_lightmap_texcoord()
            bpy.context.scene.render.engine = orig_render

            tree = material.node_tree
            nodes = material.node_tree.nodes
            for node in nodes:
                nodes.remove(node)

            links = tree.links
            group_node = tree.nodes.new("ShaderNodeGroup")
            group_node.node_tree = bpy.data.node_groups[f'SC_shader_uber']
            group_node.name = f'SC_shader_uber'
            group_node.location = (-40, 300)
            group_node.use_custom_color = True
            group_node.color = (0, 0, 0)
            group_node.width = 250

            uv_group_node = tree.nodes.new("ShaderNodeGroup")
            uv_group_node.node_tree = bpy.data.node_groups['Lightmap texcoord']
            uv_group_node.name = "UV"
            uv_group_node.location = (-1200, -400)

        shader_node_output_material_node = tree.nodes.new(type='ShaderNodeOutputMaterial')
        shader_node_output_material_node.location = (350, 400)
        links.new(group_node.outputs[0], shader_node_output_material_node.inputs[0])

        return {"FINISHED"}

class TOOL_PT_layout_panel_main(Panel):
    bl_label = "Materials:"
    bl_category = "SC"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "objectmode"

    def draw(self, context):
        layout = self.layout
        layout.operator("sctool.add_material", icon='IMPORT')
        layout.operator("sctool.export_material", icon='EXPORT')

class TOOL_PT_layout_panel_pose(Panel):
    bl_label = "Supercell mini tools"
    bl_category = "SC"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "posemode"

    def draw(self, context):
        layout = self.layout
        object = context.object
        scn = context.scene

        row = layout.row()
        row.prop(scn,
                 "expand", icon="TRIA_DOWN" if scn.expand else "TRIA_RIGHT",
                 icon_only=True,
                 emboss=False)
        row.label(text="Glb animation transfer:")
        if scn.expand:
            layout.label(text="Animation skeleton:")
            row = layout.row(align=True)
            row.prop_search(scn, "target_rig", bpy.data, "objects", text="")
            layout.operator("sctool.transfer")
            
class TOOL_PT_layout_panel_edit(Panel):
    bl_label = "Supercell mini tools"
    bl_category = "SC"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "editmode"

    def draw(self, context):
        layout = self.layout
        object = context.object
        scn = context.scene
        layout.operator("sctool.add_shader")

class TOOL_PT_layout_panel_shader_editor(Panel):
    bl_label = "Supercell mini tools"
    bl_category = "SC"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_context = "objectmode"

    def draw(self, context):
        layout = self.layout
        object = context.object
        scn = context.scene

        col = layout.column(align=False)
        row = col.row(align=True)
        row.operator_menu_enum("sctool.append_shader", 'shader', text="Add shader")

#classes = (OT_TOOL_add_material, TOOL_layout_panel_TransferAnim, TOOL_PT_layout_panel_main, TOOL_PT_layout_panel_pose, TOOL_PT_layout_panel_edit, OT_TOOL_export_material)
classes = (TOOL_PT_layout_panel_main, OT_TOOL_export_material, OT_TOOL_add_material, TOOL_PT_layout_panel_shader_editor, OT_TOOL_create_shader_selector, TOOL_layout_panel_TransferAnim, TOOL_PT_layout_panel_pose)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.expand = bpy.props.BoolProperty(name="",
                                                    default=True,
                                                    description="Expand the inputs interface")
    bpy.types.Scene.target_rig = bpy.props.StringProperty(name="Target Rig", default="",
                                                          description="Destination armature to re-target the action",
                                                          update=update_target_rig)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.expand
    del bpy.types.Scene.target_rig

if __name__ == "__main__":
    register()