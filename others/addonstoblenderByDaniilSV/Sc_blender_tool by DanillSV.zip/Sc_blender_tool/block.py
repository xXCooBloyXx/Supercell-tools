import importlib

if "reader" in locals():
    importlib.reload(reader)
else:
    from . import reader

if "writer" in locals():
    importlib.reload(writer)
else:
    from . import writer

Reader = reader.Reader
Writer = writer.Writer


class ScwBlock(Reader, Writer):
	def __init__(self, version: int = 2):
		self.version = version

		self.name = b"WEND"

		# self.stream.buffer = b""
		self.length = 0

	def parse(self, data: bytes):
		Reader.__init__(self, data, ">")

	def encode(self):
		Writer.__init__(self, ">")

		self.length = len(self.stream.buffer)

