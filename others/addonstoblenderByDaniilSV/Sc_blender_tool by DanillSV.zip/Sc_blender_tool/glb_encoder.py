import importlib

if "writer" in locals():
    importlib.reload(writer)
else:
    from . import writer

Writer = writer.Writer

import json

class GlbEncoder(Writer):
    def encode(self, data: dict, sceneData: dict, bin: bytes):
        materials = []
        images_raw = []
        images = []
        textures = []

        for n in data["materials"]:
            try:
                materialData = n["extensions"]["SC_shader"]
            except:
                materialData = n
            material = materialData["name"]
            materialCheck = []
            for c in sceneData:
                materialCheck.append(c['name'])
            if material not in materialCheck:
                raise Exception(f'There is no material "{material}" in the scene! Create or import another.')
            for t in sceneData:
                if material == t["name"]:
                    material1 = {}
                    material1["extensions"] = {}
                    m1 = material1["extensions"]
                    m1["SC_shader"] = {}
                    materialMain = m1["SC_shader"]
                    if t["shaderFile"] == 'uber':
                        materialMain["blendMode"] = int(t["blendMode"])
    
                        enbls = []
                        enbl = t["enables"]
    
                        if enbl["DIFFUSE"] == 1.0:
                            enbls.append("DIFFUSE")
    
                        if enbl["SPECULAR"] == 1.0:
                            enbls.append("SPECULAR")
    
                        if enbl["AMBIENT"] == 1.0:
                            enbls.append("AMBIENT")
    
                        if enbl["CLIP_PLANE_X"] == 1.0 or enbl["CLIP_PLANE_Y"] == 1.0 or enbl["CLIP_PLANE_Z"] == 1.0:
                            enbls.append("CLIP_PLANE")
    
                        if enbl["COLORIZE"] == 1.0:
                            enbls.append("COLORIZE")
    
                        if enbl["EMISSION"] == 1.0:
                            enbls.append("EMISSION")
    
                        if enbl["LIGHTMAP_DIFFUSE"] == 1.0 or enbl["LIGHTMAP_SPECULAR"] == 1.0:
                            enbls.append("LIGHTMAP")
    
                        if enbl["OPACITY"] == 1.0:
                            enbls.append("OPACITY")
    
                        materialMain["constants"] = enbls
                        materialMain["name"] = t["name"]
                        materialMain["sc_material"] = True
                        materialMain["shader"] = t["shaderFile"]
                        materialMain["variables"] = {}
                        variables = materialMain["variables"]
                        variablesScene = t["variables"]
                        variables["ambient"] = variablesScene["ambient"]
                        variables["clipPlane"] = [enbl["CLIP_PLANE_X"], enbl["CLIP_PLANE_Y"], enbl["CLIP_PLANE_Z"], 0.0]
    
                        if type(variablesScene["colorize"]) != str:
                            variables["colorize"] = variablesScene["colorize"]
                            variables["colorizeTex2D"] = [0.0, 0.0, 0.0, 1.0]
                        else:
                            if variablesScene["colorize"] not in images_raw:
                                images_raw.append(variablesScene["colorize"])
                                image = {}
                                image['uri'] = variablesScene["colorize"]
                                images.append(image)
                                texture = {}
                                texture['source'] = int(images_raw.index(variablesScene["colorize"]))
                                texture['sampler'] = 0
                                textures.append(texture)
    
                            variables["colorize"] = [1.0, 1.0, 1.0, 1.0]
                            variables["colorizeTex2D"] = {}
                            variables["colorizeTex2D"]["index"] = int(images_raw.index(variablesScene["colorize"]))
    
                        if type(variablesScene["diffuse"]) != str:
                            variables["diffuse"] = variablesScene["diffuse"]
                            variables["diffuseTex2D"] = [0.0, 0.0, 0.0, 1.0]
                        else:
                            if variablesScene["diffuse"] == '.':
                                imageName = "plug.png"
                            else:
                                imageName = variablesScene["diffuse"]
                            if imageName not in images_raw:
                                images_raw.append(imageName)
                                image = {}
                                image['uri'] = imageName
                                images.append(image)
                                texture = {}
                                texture['source'] = int(images_raw.index(imageName))
                                texture['sampler'] = 0
                                textures.append(texture)
    
                            variables["diffuse"] = [1.0, 1.0, 1.0, 1.0]
                            variables["diffuseTex2D"] = {}
                            variables["diffuseTex2D"]["index"] = int(images_raw.index(imageName))
    
                        if type(variablesScene["emission"]) != str:
                            variables["emission"] = variablesScene["emission"]
                            variables["emissionTex2D"] = [0.0, 0.0, 0.0, 1.0]
                        else:
                            if variablesScene["emission"] not in images_raw:
                                images_raw.append(variablesScene["emission"])
                                image = {}
                                image['uri'] = variablesScene["emission"]
                                images.append(image)
                                texture = {}
                                texture['source'] = int(images_raw.index(variablesScene["emission"]))
                                texture['sampler'] = 0
                                textures.append(texture)
    
                            variables["emission"] = [1.0, 1.0, 1.0, 1.0]
                            variables["emissionTex2D"] = {}
                            variables["emissionTex2D"]["index"] = int(images_raw.index(variablesScene["emission"]))
    
                        if enbl["STENCIL"] == 1.0:
                            variables["enableStencilTex"] = True
                        else:
                            variables["enableStencilTex"] = False
    
                        if variablesScene["lightmapTex2D"] == '':
                            variables["lightmapTex2D"] = [0.0, 0.0, 0.0, 1.0]
                        else:
                            if variablesScene["lightmapTex2D"] not in images_raw:
                                images_raw.append(variablesScene["lightmapTex2D"])
                                image = {}
                                image['uri'] = variablesScene["lightmapTex2D"]
                                images.append(image)
                                texture = {}
                                texture['source'] = int(images_raw.index(variablesScene["lightmapTex2D"]))
                                texture['sampler'] = 0
                                textures.append(texture)
    
                            variables["lightmapTex2D"] = {}
                            variables["lightmapTex2D"]["index"] = int(images_raw.index(variablesScene["lightmapTex2D"]))
    
                        if variablesScene["lightmapSpecularTex2D"] == '':
                            variables["lightmapSpecularTex2D"] = [0.0, 0.0, 0.0, 1.0]
                        else:
                            if variablesScene["lightmapSpecularTex2D"] not in images_raw:
                                images_raw.append(variablesScene["lightmapSpecularTex2D"])
                                image = {}
                                image['uri'] = variablesScene["lightmapSpecularTex2D"]
                                images.append(image)
                                texture = {}
                                texture['source'] = int(images_raw.index(variablesScene["lightmapSpecularTex2D"]))
                                texture['sampler'] = 0
                                textures.append(texture)
    
                            variables["lightmapSpecularTex2D"] = {}
                            variables["lightmapSpecularTex2D"]["index"] = int(images_raw.index(variablesScene["lightmapSpecularTex2D"]))
    
                        variables["opacity"] = variablesScene['opacity']
    
                        if variablesScene["opacityTex2D"] == '':
                            variables["opacityTex2D"] = [0.0, 0.0, 0.0, 1.0]
                        else:
                            if variablesScene["opacityTex2D"] not in images_raw:
                                images_raw.append(variablesScene["opacityTex2D"])
                                image = {}
                                image['uri'] = variablesScene["opacityTex2D"]
                                images.append(image)
                                texture = {}
                                texture['source'] = int(images_raw.index(variablesScene["opacityTex2D"]))
                                texture['sampler'] = 0
                                textures.append(texture)
    
                            variables["opacityTex2D"] = {}
                            variables["opacityTex2D"]["index"] = int(images_raw.index(variablesScene["opacityTex2D"]))

                        if type(variablesScene["specular"]) != str:
                            variables["specular"] = variablesScene["specular"]
                            variables["specularTex2D"] = [0.0, 0.0, 0.0, 1.0]
                        else:
                            if variablesScene["specular"] == '.':
                                imageName = "plug.png"
                            else:
                                imageName = variablesScene["specular"]
                            if imageName not in images_raw:
                                images_raw.append(imageName)
                                image = {}
                                image['uri'] = imageName
                                images.append(image)
                                texture = {}
                                texture['source'] = int(images_raw.index(imageName))
                                texture['sampler'] = 0
                                textures.append(texture)

                            variables["specular"] = [1.0, 1.0, 1.0, 1.0]
                            variables["specularTex2D"] = {}
                            variables["specularTex2D"]["index"] = int(images_raw.index(imageName))
    
                        variables["stencilScaleOffset"] = [0, 0, 0, 0]
                        variables["stencilTex2D"] = [0, 0, 0, 1]


                    materials.append(material1)

        data['images'] = images
        data['textures'] = textures
        data["materials"] = materials

        if "SC_shader" not in data['extensionsUsed']:
            data["extensionsUsed"].append("SC_shader")

        json_data = json.dumps(data, sort_keys=True, allow_nan=False, separators=(",", ":"))

        super().__init__("<")
        self.writeUInt32(len(json_data))
        self.writeChar("JSON")
        self.writeChar(json_data)

        self.writeUInt32(len(bin))
        self.stream.write(b"BIN\x00")
        self.stream.write(bin)

        magic = b"glTF"
        version = b"\x02\x00\x00\x00"
        size = int(len(magic) + len(version) + len(self.stream.buffer) + 4).to_bytes(4, "little", signed=False)

        self.result = magic + version + size + self.stream.buffer

        return self.result
