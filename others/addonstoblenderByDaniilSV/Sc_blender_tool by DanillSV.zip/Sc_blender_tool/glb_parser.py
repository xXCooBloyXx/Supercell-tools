import importlib

if "reader" in locals():
    importlib.reload(reader)
else:
    from . import reader

Reader = reader.Reader
import os
import json

class GlbParser(Reader):
	def __init__(self, path: str):
		self.path = path

		file_data = open(self.path, 'rb').read()

		super().__init__(file_data, "<")

	def parse(self):
		magic = self.stream.read(4)
		assert magic == b"glTF"
		
		version = self.readUInt32()
		size = self.readUInt32()
		
		self.length = self.readUInt32()
		self.fileType = self.readChar(4) # JSON
		if self.fileType == "FLA2":
			return "flat"
		else:
			self.materials_json = json.loads(self.readChar(self.length))

	def raw_json(self):
		return self.materials_json

	def chunk_length(self):
		return self.length + 28
	
	def glb_material(self):
		images = self.materials_json['images']
		textures = self.materials_json['textures']
		json_materials = self.materials_json['materials']
		material = []
		for i in json_materials:
			material_a = {}
			material_header = i['extensions']['SC_shader']
			material_variable = material_header["variables"]
			material_a["name"] = material_header['name']
			material_a["shaderFile"] = material_header['shader']
			material_a["blendMode"] = material_header["blendMode"]
			material_a["variables"] = {}
			variables = material_a["variables"]

			variables["ambient"] = material_variable["ambient"]

			if type(material_variable["diffuseTex2D"]) != list:
				variables["diffuse"] = images[(material_variable["diffuseTex2D"]["index"])]["uri"]
			else:
				variables["diffuse"] = material_variable["diffuse"]

			if type(material_variable["specularTex2D"]) != list:
				variables["specular"] = images[(material_variable["specularTex2D"]["index"])]["uri"]
			else:
				variables["specular"] = material_variable["specular"]

			if type(material_variable["colorizeTex2D"]) != list:
				variables["colorize"] = images[(material_variable["colorizeTex2D"]["index"])]["uri"]
			else:
				variables["colorize"] = material_variable["colorize"]

			if type(material_variable["emissionTex2D"]) != list:
				variables["emission"] = images[(material_variable["emissionTex2D"]["index"])]["uri"]
			else:
				variables["emission"] = material_variable["emissionTex2D"]

			if type(material_variable['opacityTex2D']) != list:
				variables["opacityTex2D"] = material_variable['opacityTex2D']
			else:
				variables["opacityTex2D"] = ""

			variables["opacity"] = material_variable['opacity']

			if type(material_variable["lightmapTex2D"]) != list:
				variables["lightmapTex2D"] = images[(material_variable["lightmapTex2D"]["index"])]["uri"]
			else:
				variables["lightmapTex2D"] = material_variable["lightmapTex2D"]

			if type(material_variable["lightmapSpecularTex2D"]) != list:
				variables["lightmapSpecularTex2D"] = images[(material_variable["lightmapSpecularTex2D"]["index"])]["uri"]
			else:
				variables["lightmapSpecularTex2D"] = material_variable["lightmapSpecularTex2D"]

			material_a["enables"] = {}
			enbl = material_a["enables"]
			materialConstants = material_header["constants"]

			if "AMBIENT" in materialConstants:
				enbl["AMBIENT"] = '1'
			else:
				enbl["AMBIENT"] = '0'

			if "COLORIZE" in materialConstants:
				enbl["COLORIZE"] = '1'
			else:
				enbl["COLORIZE"] = '0'

			if "DIFFUSE" in materialConstants:
				enbl["DIFFUSE"] = '1'
			else:
				enbl["DIFFUSE"] = '0'

			if "SPECULAR" in materialConstants:
				enbl["SPECULAR"] = '1'
			else:
				enbl["SPECULAR"] = '0'

			if "LIGHTMAP" in materialConstants:
				enbl["LIGHTMAP_DIFFUSE"] = '1'
				enbl["LIGHTMAP_SPECULAR"] = '1'
			else:
				enbl["LIGHTMAP_DIFFUSE"] = '0'
				enbl["LIGHTMAP_SPECULAR"] = '0'

			if "EMISSION" in materialConstants:
				enbl["EMISSION"] = '1'
			else:
				enbl["EMISSION"] = '1'

			if "OPACITY" in materialConstants:
				enbl["OPACITY"] = '1'
			else:
				enbl["OPACITY"] = '0'

			if "clipPlane" in material_variable:
				enbl["CLIP_PLANE_X"] = material_variable['clipPlane'][0]
				enbl["CLIP_PLANE_Y"] = material_variable['clipPlane'][1]
				enbl["CLIP_PLANE_Z"] = material_variable['clipPlane'][2]
			else:
				enbl["CLIP_PLANE_X"] = False
				enbl["CLIP_PLANE_Y"] = False
				enbl["CLIP_PLANE_Z"] = False

			enbl["SPECULAR_COMBINE"] = '0'

			material.append(material_a)

		self.materials = material
		return self.materials

