import importlib

if "block" in locals():
	importlib.reload(block)
else:
	from . import block

ScwBlock = block.ScwBlock

class Header(ScwBlock):
	def __init__(self):
		super().__init__()
		
		self.name = b"HEAD"
	
	def parse(self, data: bytes):
		super().parse(data)
		
		header = {}
		
		header["scwVersion"] = self.readUShort()
		header["sceneFrameRate"] = self.readUShort()
		
		header["timelineStart"] = self.readUShort()
		header["timelineEnd"] = self.readUShort()
		
		header["materialsFile"] = self.readUTF()
		
		header["unknownBoolean"] = False
		if header["scwVersion"] == 2:
			header["unknownBoolean"] = self.readBool()
		
		return header

	def encode(self, header: dict):
		super().encode()

		self.writeUShort(header["scwVersion"])
		self.writeUShort(header["sceneFrameRate"])
		self.writeUShort(header["timelineStart"])
		self.writeUShort(header["timelineEnd"])
		self.writeUTF(header["materialsFile"])

		if header["scwVersion"] == 2:
			if "unknownBoolean" in header:
				self.writeBool(header["unknownBoolean"])
			else:
				self.writeBool(False)

		self.length = len(self.stream.buffer)



