import importlib

if "block" in locals():
	importlib.reload(block)
else:
	from . import block

ScwBlock = block.ScwBlock
import os

class Material(ScwBlock):
	def __init__(self):
		super().__init__(2)
		
		self.name = b"MATE"
	
	def parse(self, data: bytes):
		super().parse(data)
		
		material = {}
		
		material["name"] = self.readUTF()
		material["shaderFile"] = self.readUTF()
		
		material["blendMode"] = self.readUByte()
		
		material["variables"] = {}
		variables = material["variables"]
		
		variables["ambient"] = self.parse_variable()
		if type(variables["ambient"]) != str:
			variables["ambient"].reverse()

		variables["diffuse"] = self.parse_variable()
		if type(variables["diffuse"]) != str:
			variables["diffuse"].reverse()

		variables["specular"] = self.parse_variable()
		if type(variables["specular"]) != str:
			variables["specular"].reverse()
		
		variables["unk1"] = self.readUTF()
		variables["unk2"] = self.readUTF()
		
		variables["colorize"] = self.parse_variable()
		if type(variables["colorize"]) != str:
			variables["colorize"].reverse()

		variables["emission"] = self.parse_variable()
		if type(variables["emission"]) != str:
			variables["emission"].reverse()
		
		variables["opacityTex2D"] = self.readUTF()
		
		variables["opacity"] = self.readFloat()
		variables["unknownFloat"] = self.readFloat()
		
		variables["lightmapTex2D"] = self.readUTF()
		variables["lightmapSpecularTex2D"] = self.readUTF()
		
		variables["unk3"] = ""
		if self.version == 2:
			variables["unk3"] = self.readUTF()
		
		material["shaderDefineFlags"] = self.readUInt32()
		if material["shaderDefineFlags"] & 32768:
			self.readFloat()
			self.readFloat()
			self.readFloat()
			self.readFloat()
			# stencil scale and offset maybe

		material["enables"] = {}
		enbl = material["enables"]
		enbl["AMBIENT"] = '0'
		enbl["CLIP_PLANE_X"] = '0'
		enbl["CLIP_PLANE_Y"] = '0'
		enbl["CLIP_PLANE_Z"] = '0'
		enbl["COLORIZE"] = '0'
		enbl["DIFFUSE"] = '0'
		enbl["SPECULAR"] = '0'
		enbl["SPECULAR_COMBINE"] = '0'
		enbl["EMISSION"] = '0'
		enbl["LIGHTMAP_DIFFUSE"] = '0'
		enbl["LIGHTMAP_SPECULAR"] = '0'
		enbl["OPACITY"] = '0'

		define = str(material["shaderDefineFlags"])
		self.splitDefine = list(str(material["shaderDefineFlags"]))
		if len(self.splitDefine) == 5:
			enbl["CLIP_PLANE_Z"] = '1'
			define = define[:4]

		if define == "3014" or define == "2242" or define == "3266" or define == '3578' or define == '2246':
			enbl["DIFFUSE"] = '1'
			enbl["SPECULAR"] = '1'
			enbl["LIGHTMAP_DIFFUSE"] = '1'
			enbl["LIGHTMAP_SPECULAR"] = '1'
		elif define == "3042" or define == '3581' or define == '3298':
			enbl["DIFFUSE"] = '1'
			enbl["SPECULAR"] = '1'
			enbl["LIGHTMAP_DIFFUSE"] = '1'
			enbl["LIGHTMAP_SPECULAR"] = '1'
			enbl["OPACITY"] = '1'
		elif define == "2058":
			enbl["COLORIZE"] = '1'
			enbl["LIGHTMAP_DIFFUSE"] = '1'
		elif define == "3146":
			enbl["COLORIZE"] = '1'
			enbl["DIFFUSE"] = '1'
		elif define == "2114" or define == "2050":
			enbl["DIFFUSE"] = '1'
		elif define == "3138":
			enbl["DIFFUSE"] = '1'
			enbl["LIGHTMAP_DIFFUSE"] = '1'
		elif define == '2258' or define == '3579':
			enbl["DIFFUSE"] = '1'
			enbl["SPECULAR"] = '1'
			enbl["EMISSION"] = '1'
			enbl["LIGHTMAP_DIFFUSE"] = '1'
			enbl["LIGHTMAP_SPECULAR"] = '1'
		elif define == '2246':
			enbl["DIFFUSE"] = '1'
			enbl["SPECULAR"] = '1'
			enbl["SPECULAR_COMBINE"] = '1'
			enbl["LIGHTMAP_DIFFUSE"] = '1'
			enbl["LIGHTMAP_SPECULAR"] = '1'
		else:
			enbl["DIFFUSE"] = '1'
			enbl["SPECULAR"] = '1'
			enbl["LIGHTMAP_DIFFUSE"] = '1'
			enbl["LIGHTMAP_SPECULAR"] = '1'
			print(f'Unknown shader define, {define} in {material["name"]}!')

		return material
	
	def parse_variable(self):
		if self.readBool():
			return self.readUTF()
		return [
			self.readNUByte(),
			self.readNUByte(),
			self.readNUByte(),
			self.readNUByte()
		]

	def encode(self, material: dict):
		super().encode()

		self.writeUTF(material["name"])
		self.writeUTF(f"shader/{material['shaderFile']}.vsh")

		self.writeUByte(material["blendMode"])

		variables = material["variables"]

		self.encode_variable(variables["ambient"])
		self.encode_variable(variables["diffuse"])
		self.encode_variable(variables["specular"])

		self.writeUTF(variables["unk1"])
		self.writeUTF(variables["unk1"])

		self.encode_variable(variables["colorize"])
		self.encode_variable(variables["emission"])

		self.writeUTF(variables["opacityTex2D"])

		self.writeFloat(variables["opacity"])
		self.writeFloat(variables["unknownFloat"])

		self.writeUTF(variables["lightmapTex2D"])
		self.writeUTF(variables["lightmapSpecularTex2D"])

		if self.version == 2:
			if "unk3" in variables:
				self.writeUTF(variables["unk3"])
			else:
				self.writeUTF("")

		self.writeUInt32(material["shaderDefineFlags"])
		if material["shaderDefineFlags"] & 32768:
			self.writeFloat(0)
			self.writeFloat(0)
			self.writeFloat(0)
			self.writeFloat(0)

		self.length = len(self.stream.buffer)

	def encode_variable(self, variable: str or list):
		if type(variable) is str:
			self.writeBool(True)

			self.writeUTF(variable)
		elif type(variable) is list:
			self.writeBool(False)

			self.writeNUByte(variable[3])
			self.writeNUByte(variable[2])
			self.writeNUByte(variable[1])
			self.writeNUByte(variable[0])
		else:
			self.writeBool(False)

			self.writeUInt32(0xff000000)