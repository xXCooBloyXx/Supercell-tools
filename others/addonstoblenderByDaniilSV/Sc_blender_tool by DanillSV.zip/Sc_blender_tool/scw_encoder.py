if "block" in locals():
	importlib.reload(block)
else:
	from . import block

ScwBlock = block.ScwBlock

from binascii import crc32

if "header" in locals():
    importlib.reload(header)
else:
    from . import header

HEAD = header.Header

if "material" in locals():
    importlib.reload(material)
else:
    from . import material

MATE = material.Material


class ScwWriter:
	def __init__(self):
		self.result = b"SC3D" # MAGIC
	
	def encode(self, data: dict):
		header = data["header"]
		materials = data["materials"]
		
		# Scw header
		head = HEAD()
		head.encode(header)

		self.write_chunk(head)
		
		# Scw materials
		for material in materials:
			#mate = MATE(header["scwVersion"])
			mate = MATE()
			mate.encode(material)
			
			self.write_chunk(mate)
	
	def write_chunk(self, chunk: ScwBlock):
		length = int(chunk.length).to_bytes(4, "big", signed=False)
		type = chunk.name
		data = chunk.stream.buffer
		crc = int(crc32(type + data)).to_bytes(4, "big", signed=False)
		
		self.result += length + type + data + crc