import importlib

if "reader" in locals():
    importlib.reload(reader)
else:
    from . import reader

Reader = reader.Reader

if "header" in locals():
    importlib.reload(header)
else:
    from . import header

HEAD = header.Header

if "material" in locals():
    importlib.reload(material)
else:
    from . import material

MATE = material.Material

class ScwParser(Reader):
	def __init__(self):
		self.header = {}
		self.materials = []
	
	def parse(self, data: bytes):
		super().__init__(data, ">")
		self.materials = []
		
		magic = self.stream.read(4)
		self.chunksLength = 4
		if magic != b"SC3D":
			raise IOError("Bad file magic!")

		
		while not self.stream.eof():
			length = self.readUInt32()
			type = self.readChar(4)
			data = self.stream.read(length)
			crc = self.readUInt32()

			if type == "HEAD":
				head = HEAD()
				
				self.header = head.parse(data)
				self.chunksLength += length + 12
			elif type == "MATE":
				mate = MATE()

				self.materials.append(mate.parse(data))
				self.chunksLength += length + 12
			else:
				break

		return self.chunksLength

	def scw_header(self):
		return self.header

	def scw_material(self):
		return self.materials
